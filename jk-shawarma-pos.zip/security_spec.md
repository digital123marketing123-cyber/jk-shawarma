# Security Specification — JK Shawarma POS

## 1. Data Invariants
1. **Multi-User Isolation**: Every order (`/users/{userId}/orders/{orderId}`) and custom menu item (`/users/{userId}/menu_items/{itemId}`) belongs strictly to the authenticated restaurant account (`request.auth.uid == userId && incoming().userId == request.auth.uid`).
2. **Path & ID Hardening**: All path parameters (`userId`, `orderId`, `itemId`) must match `^[a-zA-Z0-9_\-]+$` and be at most 128 characters.
3. **Strict Schema & Bounds**:
   - `OrderRecord`: Requires `id`, `userId`, `tokenNumber`, `dateKey`, `dateDisplay`, `timeDisplay`, `customerPhone`, `customerName`, `orderType`, `paymentMethod`, `subtotalAmount`, `discountAmount`, `discountLabel`, `totalAmount`, `totalQuantity`, `items`, `status`, `createdAt`, `updatedAt`.
   - `MenuItem`: Requires `id`, `userId`, `name`, `category`, `price`, `isVeg`, `isAvailable`, `createdAt`, `updatedAt`.
4. **Terminal State Locking**: Orders with `status` in `['COMPLETED', 'CANCELLED']` are terminal and cannot be modified further (`existing().status == 'ACTIVE'`).
5. **Temporal Integrity**: `createdAt` and `updatedAt` must be valid server timestamps (`<= request.time`), and `createdAt` is immutable on update.
6. **Query Alignment**: `allow list` enforces `request.auth.uid == userId && resource.data.userId == request.auth.uid`.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Read/Write**: `auth == null` reading or writing `/users/u1/orders/o1`.
2. **Cross-User Read/List**: Authenticated `bob_456` reading `/users/alice_123/orders/o1`.
3. **Identity Spoofing on Create**: Authenticated `alice_123` writing to `/users/alice_123/orders/o1` with `userId: "bob_456"`.
4. **Shadow Update / Ghost Field Injection**: Including `"isVerified": true` in order creation or update.
5. **Immutable Field Tampering**: Updating `createdAt`, `userId`, or `tokenNumber` on an existing order.
6. **Terminal State Bypass**: Updating an order whose `existing().status` is `'COMPLETED'` or `'CANCELLED'`.
7. **Value Poisoning (Negative Price/Total)**: Creating an order with `totalAmount: -500` or menu item with `price: 0`.
8. **Empty/Oversized Line Items List**: Creating an order with `items: []` or `items` > 50 elements.
9. **Oversized String Exhaustion**: Injecting a 5,000-character string into `customerName` or `name`.
10. **Invalid Enum Value**: Setting `paymentMethod: "CRYPTO"` or `orderType: "INVALID"`.
11. **Future Timestamp Injection**: Setting `createdAt` to a timestamp in the future (`> request.time`).
12. **Unfiltered List Query**: Querying `orders` without `.where("userId", "==", uid)`.
