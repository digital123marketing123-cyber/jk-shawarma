const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function makeValidOrder(userId, orderId = "order_001", status = "ACTIVE") {
  const now = new Date();
  return {
    id: orderId,
    userId: userId,
    tokenNumber: 1,
    dateKey: "2026-09-30",
    dateDisplay: "30 Sep 2026",
    timeDisplay: "02:30 PM",
    customerPhone: "8688553379",
    customerName: "Walk-in Customer",
    orderType: "TAKEAWAY",
    paymentMethod: "UPI",
    subtotalAmount: 300,
    discountAmount: 20,
    discountLabel: "Promo ₹20",
    totalAmount: 280,
    totalQuantity: 2,
    items: [
      {
        itemId: "item_1",
        name: "Special Chicken Shawarma",
        category: "JK SPECIAL SHAWARMA",
        unitPrice: 150,
        quantity: 2,
        lineTotal: 300,
      },
    ],
    status: status,
    createdAt: now,
    updatedAt: now,
  };
}

function makeValidMenuItem(userId, itemId = "menu_1") {
  const now = new Date();
  return {
    id: itemId,
    userId: userId,
    name: "Special Loaded Jumbo",
    category: "JK SPECIAL SHAWARMA",
    price: 220,
    isVeg: false,
    isAvailable: true,
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or create orders", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("orders").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("orders").doc("order_001").set(makeValidOrder(ALICE_UID))
  );
});

test("Authenticated user: can create and read own order", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("order_001").set(makeValidOrder(ALICE_UID))
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated user: cannot read another user's orders", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(BOB_UID)
      .collection("orders")
      .doc("order_bob")
      .set(makeValidOrder(BOB_UID, "order_bob"));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("orders").doc("order_bob").get()
  );
});

test("Shadow update with ghost field is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const payloadWithGhost = {
    ...makeValidOrder(ALICE_UID),
    isVerified: true,
  };
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("order_001").set(payloadWithGhost)
  );
});

test("Terminal state locking: COMPLETED order cannot be updated", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("orders")
      .doc("order_done")
      .set(makeValidOrder(ALICE_UID, "order_done", "COMPLETED"));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("orders")
      .doc("order_done")
      .update({ status: "CANCELLED", updatedAt: new Date() })
  );
});

test("Authenticated user: can create and update own custom menu item", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("menu_items").doc("menu_1").set(makeValidMenuItem(ALICE_UID))
  );
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("menu_items")
      .doc("menu_1")
      .update({ price: 230, updatedAt: new Date() })
  );
});
