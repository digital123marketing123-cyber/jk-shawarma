package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.LocalPosSessionStore
import com.example.data.model.RestaurantInfo
import com.example.ui.PosViewModel
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.components.TokenReceiptDialog
import com.example.ui.screens.MenuAndSyncScreen
import com.example.ui.screens.NewOrderPosScreen
import com.example.ui.screens.SettlementReportScreen
import com.example.ui.screens.TokenHistoryScreen
import com.example.ui.theme.CrownGold
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ShawarmaOrange
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

enum class PosDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
) {
    NEW_TOKEN(
        route = "new_token",
        label = "New Token",
        icon = Icons.Default.PointOfSale,
        testTag = "nav_tab_new_token"
    ),
    TOKEN_HISTORY(
        route = "token_history",
        label = "Tokens",
        icon = Icons.Default.ConfirmationNumber,
        testTag = "nav_tab_tokens"
    ),
    SETTLEMENT(
        route = "settlement",
        label = "Settlement",
        icon = Icons.Default.Assessment,
        testTag = "nav_tab_settlement"
    ),
    MENU_AND_SYNC(
        route = "menu_sync",
        label = "Menu & Sync",
        icon = Icons.Default.RestaurantMenu,
        testTag = "nav_tab_menu_sync"
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalPosSessionStore.ensureInitialized(this)
        enableEdgeToEdge()
        setContent {
            var isDarkTheme by rememberSaveable { mutableStateOf(true) }
            MyApplicationTheme(darkTheme = isDarkTheme) {
                AppNavigation(
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = { isDarkTheme = !isDarkTheme }
                )
            }
        }
    }
}

@Composable
fun AppNavigation(
    auth: FirebaseAuth = Firebase.auth,
    isDarkTheme: Boolean = true,
    onToggleTheme: () -> Unit = {}
) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        LocalPosSessionStore.ensureInitialized(context)
    }

    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val isPosLoggedIn by LocalPosSessionStore.isPosAuthenticated.collectAsStateWithLifecycle()
    var sessionUnlocked by rememberSaveable { mutableStateOf(false) }
    val user = currentUser

    val hasValidSession = sessionUnlocked ||
        isPosLoggedIn ||
        (user != null && LocalPosSessionStore.isApprovedGoogleEmail(user.email))

    if (!hasValidSession) {
        AuthScreen(
            onAuthSuccess = {
                sessionUnlocked = true
            }
        )
    } else {
        val activeUid = user?.uid ?: RestaurantInfo.APPROVED_USER_ID
        val activeEmail = user?.email ?: RestaurantInfo.APPROVED_EMAIL
        MainPosFeatureScreen(
            currentUserId = activeUid,
            userEmail = activeEmail,
            isCloudAuthenticated = user != null,
            isDarkTheme = isDarkTheme,
            onToggleTheme = onToggleTheme,
            onLoggedOut = {
                sessionUnlocked = false
            }
        )
    }
}

@Composable
fun MainPosFeatureScreen(
    currentUserId: String,
    userEmail: String?,
    isCloudAuthenticated: Boolean,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onLoggedOut: () -> Unit = {}
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val posViewModel: PosViewModel = viewModel(
        key = "pos_vm_${currentUserId}_$isCloudAuthenticated",
        factory = PosViewModel.Factory(application, currentUserId, isCloudAuthenticated)
    )

    val formState by posViewModel.formState.collectAsStateWithLifecycle()
    val ordersState by posViewModel.ordersState.collectAsStateWithLifecycle()
    val menuCatalog by posViewModel.mergedMenuCatalog.collectAsStateWithLifecycle()
    val nextTokenNumber by posViewModel.nextTokenNumber.collectAsStateWithLifecycle()
    val settlementSummary by posViewModel.settlementSummary.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(PosDestination.NEW_TOKEN) }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    // Mandatory BackHandler for secondary tabs
    if (currentTab != PosDestination.NEW_TOKEN) {
        BackHandler {
            currentTab = PosDestination.NEW_TOKEN
        }
    }

    LaunchedEffect(formState.statusBannerMessage) {
        val msg = formState.statusBannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            posViewModel.clearBannerMessage()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 760.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        PosDestination.entries.forEach { dest ->
                            val isSelected = currentTab == dest
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentTab = dest },
                                icon = {
                                    if (dest == PosDestination.NEW_TOKEN && formState.totalCartQuantity > 0L) {
                                        BadgedBox(
                                            badge = {
                                                Badge(containerColor = ShawarmaOrange) {
                                                    Text(formState.totalCartQuantity.toString())
                                                }
                                            }
                                        ) {
                                            Icon(dest.icon, contentDescription = dest.label)
                                        }
                                    } else {
                                        Icon(dest.icon, contentDescription = dest.label)
                                    }
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = CrownGold,
                                    indicatorColor = ShawarmaOrange
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        PosDestination.entries.forEach { dest ->
                            val isSelected = currentTab == dest
                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { currentTab = dest },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        PosDestination.NEW_TOKEN -> {
                            NewOrderPosScreen(
                                viewModel = posViewModel,
                                formState = formState,
                                menuCatalog = menuCatalog,
                                nextTokenNumber = nextTokenNumber
                            )
                        }

                        PosDestination.TOKEN_HISTORY -> {
                            TokenHistoryScreen(
                                ordersState = ordersState,
                                viewModel = posViewModel
                            )
                        }

                        PosDestination.SETTLEMENT -> {
                            SettlementReportScreen(
                                settlement = settlementSummary,
                                formState = formState,
                                viewModel = posViewModel
                            )
                        }

                        PosDestination.MENU_AND_SYNC -> {
                            MenuAndSyncScreen(
                                menuCatalog = menuCatalog,
                                userEmail = userEmail,
                                isCloudConnected = isCloudAuthenticated,
                                isDarkTheme = isDarkTheme,
                                onToggleTheme = onToggleTheme,
                                onSignOut = {
                                    signOut(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onSignOutComplete = onLoggedOut,
                                        scope = coroutineScope
                                    )
                                },
                                viewModel = posViewModel
                            )
                        }
                    }
                }
            }
        }
    }

    // Active Token & Invoice Receipt Modal Dialog
    val activeReceipt = formState.activeReceiptOrder
    if (activeReceipt != null) {
        TokenReceiptDialog(
            order = activeReceipt,
            onDismiss = posViewModel::dismissReceiptPreview,
            onUpdatePhone = { newPhone ->
                posViewModel.updateActiveReceiptPhoneAndOrder(activeReceipt, newPhone)
            },
            onMarkCompleted = {
                posViewModel.markOrderStatus(activeReceipt, "COMPLETED")
            },
            onCancelOrder = {
                posViewModel.markOrderStatus(activeReceipt, "CANCELLED")
            }
        )
    }
}
