package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue

object RestaurantInfo {
    const val NAME = "JK ARABIAN SHAWARMA"
    const val SUBTITLE = "& GRILL HOUSE"
    const val FULL_NAME = "JK ARABIAN SHAWARMA & GRILL HOUSE"
    const val CONTACT = "86885 53379"
    const val CLEAN_CONTACT = "918688553379"
    const val ADDRESS = "RTO Office Road, Siddhardha Nagar, Kakinada."
    const val DEVELOPER_CREDIT = "Developed by JANI ADS"
    const val APPROVED_USER_ID = "janiads"
    const val APPROVED_PASSWORD = "Janiads001"
    const val APPROVED_EMAIL = "janidigitalads@gmail.com"
    const val SECONDARY_APPROVED_EMAIL = "digital123marketing123@gmail.com"
}

object MenuCategories {
    const val VEG_SHAWARMA = "VEG SHAWARMA"
    const val GRILLED_CHICKEN = "GRILLED CHICKEN"
    const val CHICKEN_SHAWARMA = "CHICKEN SHAWARMA"
    const val JK_SPECIAL_SHAWARMA = "JK SPECIAL SHAWARMA"
    const val BREADS_AND_EXTRAS = "BREADS & EXTRAS"

    val ALL = listOf(
        CHICKEN_SHAWARMA,
        JK_SPECIAL_SHAWARMA,
        GRILLED_CHICKEN,
        VEG_SHAWARMA,
        BREADS_AND_EXTRAS
    )

    fun displayTitle(category: String): String = when (category) {
        CHICKEN_SHAWARMA -> "CHICKEN SHAWARMA (WITH SALAD)"
        else -> category
    }
}

data class MenuItem(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val category: String = MenuCategories.CHICKEN_SHAWARMA,
    val price: Long = 0L,
    val isVeg: Boolean = false,
    val isAvailable: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf<String, Any?>(
        "id" to id,
        "userId" to uid,
        "name" to name.trim().take(100),
        "category" to category,
        "price" to price.coerceIn(1L, 100000L),
        "isVeg" to isVeg,
        "isAvailable" to isAvailable,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }.mapValues { it.value!! }

    fun toUpdateMap(): Map<String, Any> = mapOf<String, Any?>(
        "name" to name.trim().take(100),
        "category" to category,
        "price" to price.coerceIn(1L, 100000L),
        "isVeg" to isVeg,
        "isAvailable" to isAvailable,
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }.mapValues { it.value!! }

    companion object {
        fun fromSnapshot(doc: DocumentSnapshot): MenuItem? {
            if (!doc.exists()) return null
            val id = doc.getString("id") ?: doc.id
            val userId = doc.getString("userId") ?: ""
            val name = doc.getString("name") ?: return null
            val category = doc.getString("category") ?: MenuCategories.CHICKEN_SHAWARMA
            val price = doc.getLong("price") ?: 0L
            val isVeg = doc.getBoolean("isVeg") ?: false
            val isAvailable = doc.getBoolean("isAvailable") ?: true
            val createdAt = doc.getTimestamp(
                "createdAt",
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val updatedAt = doc.getTimestamp(
                "updatedAt",
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            return MenuItem(
                id = id,
                userId = userId,
                name = name,
                category = category,
                price = price,
                isVeg = isVeg,
                isAvailable = isAvailable,
                createdAt = createdAt,
                updatedAt = updatedAt
            )
        }
    }
}

data class OrderLineItem(
    val itemId: String = "",
    val name: String = "",
    val category: String = "",
    val unitPrice: Long = 0L,
    val quantity: Long = 1L,
    val lineTotal: Long = 0L
) {
    fun toMap(): Map<String, Any> = mapOf(
        "itemId" to itemId,
        "name" to name.take(100),
        "category" to category.take(60),
        "unitPrice" to unitPrice,
        "quantity" to quantity,
        "lineTotal" to lineTotal
    )

    companion object {
        fun fromMap(map: Map<*, *>): OrderLineItem {
            val itemId = (map["itemId"] as? String) ?: "item"
            val name = (map["name"] as? String) ?: "Item"
            val category = (map["category"] as? String) ?: MenuCategories.CHICKEN_SHAWARMA
            val unitPrice = (map["unitPrice"] as? Number)?.toLong() ?: 0L
            val quantity = (map["quantity"] as? Number)?.toLong() ?: 1L
            val lineTotal = (map["lineTotal"] as? Number)?.toLong() ?: (unitPrice * quantity)
            return OrderLineItem(
                itemId = itemId,
                name = name,
                category = category,
                unitPrice = unitPrice,
                quantity = quantity,
                lineTotal = lineTotal
            )
        }
    }
}

data class OrderRecord(
    val id: String = "",
    val userId: String = "",
    val tokenNumber: Long = 1L,
    val dateKey: String = "",
    val dateDisplay: String = "",
    val timeDisplay: String = "",
    val customerPhone: String = "",
    val customerName: String = "",
    val orderType: String = "TAKEAWAY",
    val paymentMethod: String = "CASH",
    val subtotalAmount: Long = 0L,
    val discountAmount: Long = 0L,
    val discountLabel: String = "",
    val totalAmount: Long = 0L,
    val totalQuantity: Long = 1L,
    val items: List<OrderLineItem> = emptyList(),
    val status: String = "ACTIVE",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "id" to id,
        "userId" to uid,
        "tokenNumber" to tokenNumber.coerceIn(1L, 999999L),
        "dateKey" to dateKey.take(10),
        "dateDisplay" to dateDisplay.take(40),
        "timeDisplay" to timeDisplay.take(40),
        "customerPhone" to customerPhone.trim().take(20),
        "customerName" to customerName.trim().take(80),
        "orderType" to orderType,
        "paymentMethod" to paymentMethod,
        "subtotalAmount" to subtotalAmount.coerceAtLeast(0L),
        "discountAmount" to discountAmount.coerceIn(0L, subtotalAmount.coerceAtLeast(0L)),
        "discountLabel" to discountLabel.take(60),
        "totalAmount" to totalAmount.coerceAtLeast(0L),
        "totalQuantity" to totalQuantity.coerceAtLeast(1L),
        "items" to items.take(50).map { it.toMap() },
        "status" to status,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }

    companion object {
        fun fromSnapshot(doc: DocumentSnapshot): OrderRecord? {
            if (!doc.exists()) return null
            val id = doc.getString("id") ?: doc.id
            val userId = doc.getString("userId") ?: ""
            val tokenNumber = doc.getLong("tokenNumber") ?: 1L
            val dateKey = doc.getString("dateKey") ?: ""
            val dateDisplay = doc.getString("dateDisplay") ?: ""
            val timeDisplay = doc.getString("timeDisplay") ?: ""
            val customerPhone = doc.getString("customerPhone") ?: ""
            val customerName = doc.getString("customerName") ?: ""
            val orderType = doc.getString("orderType") ?: "TAKEAWAY"
            val paymentMethod = doc.getString("paymentMethod") ?: "CASH"
            val subtotalAmount = doc.getLong("subtotalAmount") ?: 0L
            val discountAmount = doc.getLong("discountAmount") ?: 0L
            val discountLabel = doc.getString("discountLabel") ?: ""
            val totalAmount = doc.getLong("totalAmount") ?: 0L
            val totalQuantity = doc.getLong("totalQuantity") ?: 1L
            val status = doc.getString("status") ?: "ACTIVE"
            val rawItems = doc.get("items") as? List<*> ?: emptyList<Any>()
            val items = rawItems.mapNotNull { entry ->
                (entry as? Map<*, *>)?.let { OrderLineItem.fromMap(it) }
            }
            val createdAt = doc.getTimestamp(
                "createdAt",
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val updatedAt = doc.getTimestamp(
                "updatedAt",
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            return OrderRecord(
                id = id,
                userId = userId,
                tokenNumber = tokenNumber,
                dateKey = dateKey,
                dateDisplay = dateDisplay,
                timeDisplay = timeDisplay,
                customerPhone = customerPhone,
                customerName = customerName,
                orderType = orderType,
                paymentMethod = paymentMethod,
                subtotalAmount = subtotalAmount,
                discountAmount = discountAmount,
                discountLabel = discountLabel,
                totalAmount = totalAmount,
                totalQuantity = totalQuantity,
                items = items,
                status = status,
                createdAt = createdAt,
                updatedAt = updatedAt
            )
        }
    }
}

object DefaultMenuCatalog {
    val ITEMS: List<MenuItem> = listOf(
        // VEG SHAWARMA
        MenuItem(
            id = "veg_lays_shawarma",
            name = "Veg Lays Shawarma",
            category = MenuCategories.VEG_SHAWARMA,
            price = 90L,
            isVeg = true
        ),
        MenuItem(
            id = "veg_panner_shawarma",
            name = "Veg Panner Shawarma",
            category = MenuCategories.VEG_SHAWARMA,
            price = 110L,
            isVeg = true
        ),
        MenuItem(
            id = "veg_loaded_bag_shawarma",
            name = "Veg Loaded bag Shawarma",
            category = MenuCategories.VEG_SHAWARMA,
            price = 130L,
            isVeg = true
        ),

        // GRILLED CHICKEN
        MenuItem(
            id = "full_grill_chicken",
            name = "Full Grill Chicken",
            category = MenuCategories.GRILLED_CHICKEN,
            price = 500L,
            isVeg = false
        ),
        MenuItem(
            id = "half_grill_chicken",
            name = "Half Grill Chicken",
            category = MenuCategories.GRILLED_CHICKEN,
            price = 280L,
            isVeg = false
        ),

        // CHICKEN SHAWARMA (WITH SALAD)
        MenuItem(
            id = "chicken_shawarma",
            name = "Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 110L,
            isVeg = false
        ),
        MenuItem(
            id = "peri_peri_chicken_shawarma",
            name = "Peri Peri Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 130L,
            isVeg = false
        ),
        MenuItem(
            id = "barbeque_chicken_shawarma",
            name = "Barbeque Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 130L,
            isVeg = false
        ),
        MenuItem(
            id = "schezwan_chicken_shawarma",
            name = "Schezwan Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 140L,
            isVeg = false
        ),
        MenuItem(
            id = "cheese_chicken_shawarma",
            name = "Cheese Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 140L,
            isVeg = false
        ),
        MenuItem(
            id = "kaju_chicken_shawarma",
            name = "Kaju Chicken Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 140L,
            isVeg = false
        ),
        MenuItem(
            id = "loaded_jumbo_shawarma",
            name = "Loaded Jumbo Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 170L,
            isVeg = false
        ),
        MenuItem(
            id = "loaded_bowl_shawarma",
            name = "Loaded Bowl Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 170L,
            isVeg = false
        ),
        MenuItem(
            id = "jk_special_shawarma",
            name = "JK Special Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 180L,
            isVeg = false
        ),
        MenuItem(
            id = "loaded_bag_shawaram",
            name = "Loaded bag shawaram",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 190L,
            isVeg = false
        ),
        MenuItem(
            id = "jk_pot_shawarma",
            name = "JK Pot Shawarma",
            category = MenuCategories.CHICKEN_SHAWARMA,
            price = 190L,
            isVeg = false
        ),

        // JK SPECIAL SHAWARMA
        MenuItem(
            id = "special_chicken_shawarma",
            name = "Special Chicken Shawarma",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 150L,
            isVeg = false
        ),
        MenuItem(
            id = "special_peri_peri_shawarma",
            name = "Special Peri Peri Shawarma",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 170L,
            isVeg = false
        ),
        MenuItem(
            id = "special_schezwan_shawarma",
            name = "Special Schezwan Shawarma",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 180L,
            isVeg = false
        ),
        MenuItem(
            id = "special_cheese_shawarma",
            name = "Special Cheese Shawarma",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 180L,
            isVeg = false
        ),
        MenuItem(
            id = "special_kaju_shawarma",
            name = "Special Kaju Shawarma",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 180L,
            isVeg = false
        ),
        MenuItem(
            id = "special_loaded_jumbo",
            name = "Special Loaded Jumbo",
            category = MenuCategories.JK_SPECIAL_SHAWARMA,
            price = 220L,
            isVeg = false
        ),

        // BREADS & EXTRAS
        MenuItem(
            id = "rumali_roti",
            name = "Rumali Roti",
            category = MenuCategories.BREADS_AND_EXTRAS,
            price = 25L,
            isVeg = true
        ),
        MenuItem(
            id = "mayonnaise_extra",
            name = "Mayonnaise (Extra)",
            category = MenuCategories.BREADS_AND_EXTRAS,
            price = 20L,
            isVeg = true
        ),
        MenuItem(
            id = "pudina_chutney_extra",
            name = "Pudina Chutney (Extra)",
            category = MenuCategories.BREADS_AND_EXTRAS,
            price = 20L,
            isVeg = true
        )
    )
}
