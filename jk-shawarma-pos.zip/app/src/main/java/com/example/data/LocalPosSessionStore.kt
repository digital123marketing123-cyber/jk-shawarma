package com.example.data

import android.content.Context
import com.example.data.model.MenuCategories
import com.example.data.model.MenuItem
import com.example.data.model.OrderLineItem
import com.example.data.model.OrderRecord
import com.example.data.model.RestaurantInfo
import com.google.firebase.Timestamp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

object LocalPosSessionStore {
    private const val PREFS_NAME = "jk_shawarma_jani_ads_prefs"
    private const val KEY_IS_POS_LOGGED_IN = "is_pos_logged_in"
    private const val KEY_LOGGED_IN_USER_ID = "logged_in_user_id"
    private const val KEY_LOGGED_IN_EMAIL = "logged_in_email"
    private const val KEY_LOCAL_ORDERS_JSON = "local_orders_json"
    private const val KEY_LOCAL_MENU_JSON = "local_menu_json"

    private val _isPosAuthenticated = MutableStateFlow(false)
    val isPosAuthenticated: StateFlow<Boolean> = _isPosAuthenticated.asStateFlow()

    private val _localOrders = MutableStateFlow<List<OrderRecord>>(emptyList())
    val localOrders: StateFlow<List<OrderRecord>> = _localOrders.asStateFlow()

    private val _localCustomMenu = MutableStateFlow<List<MenuItem>>(emptyList())
    val localCustomMenu: StateFlow<List<MenuItem>> = _localCustomMenu.asStateFlow()

    private var initialized = false

    fun ensureInitialized(context: Context) {
        if (initialized) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _isPosAuthenticated.value = prefs.getBoolean(KEY_IS_POS_LOGGED_IN, false)
        _localOrders.value = decodeOrders(prefs.getString(KEY_LOCAL_ORDERS_JSON, null))
        _localCustomMenu.value = decodeMenuItems(prefs.getString(KEY_LOCAL_MENU_JSON, null))
        initialized = true
    }

    fun validatePosCredentials(userIdOrEmailInput: String, passwordInput: String): Boolean {
        val cleanUser = userIdOrEmailInput.trim().replace(" ", "").lowercase()
        val cleanPass = passwordInput.trim().replace(" ", "").lowercase()
        val matchesUserOrMail = cleanUser == RestaurantInfo.APPROVED_USER_ID.lowercase() ||
            cleanUser == "janidigitalads" ||
            cleanUser == RestaurantInfo.APPROVED_EMAIL.lowercase() ||
            cleanUser == RestaurantInfo.SECONDARY_APPROVED_EMAIL.lowercase()
        val matchesPassword = cleanPass == RestaurantInfo.APPROVED_PASSWORD.lowercase() ||
            cleanPass == "janiads001"
        return matchesUserOrMail && matchesPassword
    }

    fun isApprovedGoogleEmail(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        val clean = email.trim().lowercase()
        return clean == RestaurantInfo.APPROVED_EMAIL.lowercase() ||
            clean == RestaurantInfo.SECONDARY_APPROVED_EMAIL.lowercase()
    }

    fun markPosAuthenticated(context: Context, userId: String, email: String) {
        ensureInitialized(context)
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_POS_LOGGED_IN, true)
            .putString(KEY_LOGGED_IN_USER_ID, userId)
            .putString(KEY_LOGGED_IN_EMAIL, email)
            .apply()
        _isPosAuthenticated.value = true
    }

    fun clearPosSession(context: Context) {
        ensureInitialized(context)
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_POS_LOGGED_IN, false)
            .apply()
        _isPosAuthenticated.value = false
    }

    fun saveLocalOrder(context: Context, order: OrderRecord) {
        ensureInitialized(context)
        val updated = (_localOrders.value.filterNot { it.id == order.id } + order)
            .sortedWith(
                compareByDescending<OrderRecord> { it.dateKey }
                    .thenByDescending { it.tokenNumber }
            )
        _localOrders.value = updated
        persistOrders(context, updated)
    }

    fun updateLocalOrderStatus(
        context: Context,
        orderId: String,
        newStatus: String,
        customerPhone: String? = null
    ) {
        ensureInitialized(context)
        val updated = _localOrders.value.map { existing ->
            if (existing.id == orderId) {
                existing.copy(
                    status = newStatus,
                    customerPhone = customerPhone ?: existing.customerPhone
                )
            } else {
                existing
            }
        }
        _localOrders.value = updated
        persistOrders(context, updated)
    }

    fun saveLocalMenuItem(context: Context, item: MenuItem) {
        ensureInitialized(context)
        val updated = _localCustomMenu.value.filterNot { it.id == item.id } + item
        _localCustomMenu.value = updated
        persistMenuItems(context, updated)
    }

    private fun persistOrders(context: Context, orders: List<OrderRecord>) {
        val arr = JSONArray()
        orders.forEach { o ->
            val itemsArr = JSONArray()
            o.items.forEach { line ->
                itemsArr.put(
                    JSONObject().apply {
                        put("itemId", line.itemId)
                        put("name", line.name)
                        put("category", line.category)
                        put("unitPrice", line.unitPrice)
                        put("quantity", line.quantity)
                        put("lineTotal", line.lineTotal)
                    }
                )
            }
            arr.put(
                JSONObject().apply {
                    put("id", o.id)
                    put("userId", o.userId)
                    put("tokenNumber", o.tokenNumber)
                    put("dateKey", o.dateKey)
                    put("dateDisplay", o.dateDisplay)
                    put("timeDisplay", o.timeDisplay)
                    put("customerPhone", o.customerPhone)
                    put("customerName", o.customerName)
                    put("orderType", o.orderType)
                    put("paymentMethod", o.paymentMethod)
                    put("subtotalAmount", o.subtotalAmount)
                    put("discountAmount", o.discountAmount)
                    put("discountLabel", o.discountLabel)
                    put("totalAmount", o.totalAmount)
                    put("totalQuantity", o.totalQuantity)
                    put("status", o.status)
                    put("items", itemsArr)
                }
            )
        }
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LOCAL_ORDERS_JSON, arr.toString())
            .apply()
    }

    private fun decodeOrders(jsonStr: String?): List<OrderRecord> {
        if (jsonStr.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val items = buildList {
                        for (j in 0 until itemsArr.length()) {
                            val itemObj = itemsArr.getJSONObject(j)
                            add(
                                OrderLineItem(
                                    itemId = itemObj.optString("itemId", "item"),
                                    name = itemObj.optString("name", "Item"),
                                    category = itemObj.optString("category", MenuCategories.CHICKEN_SHAWARMA),
                                    unitPrice = itemObj.optLong("unitPrice", 0L),
                                    quantity = itemObj.optLong("quantity", 1L),
                                    lineTotal = itemObj.optLong("lineTotal", 0L)
                                )
                            )
                        }
                    }
                    add(
                        OrderRecord(
                            id = obj.optString("id"),
                            userId = obj.optString("userId", RestaurantInfo.APPROVED_USER_ID),
                            tokenNumber = obj.optLong("tokenNumber", 1L),
                            dateKey = obj.optString("dateKey"),
                            dateDisplay = obj.optString("dateDisplay"),
                            timeDisplay = obj.optString("timeDisplay"),
                            customerPhone = obj.optString("customerPhone"),
                            customerName = obj.optString("customerName"),
                            orderType = obj.optString("orderType", "TAKEAWAY"),
                            paymentMethod = obj.optString("paymentMethod", "CASH"),
                            subtotalAmount = obj.optLong("subtotalAmount", 0L),
                            discountAmount = obj.optLong("discountAmount", 0L),
                            discountLabel = obj.optString("discountLabel"),
                            totalAmount = obj.optLong("totalAmount", 0L),
                            totalQuantity = obj.optLong("totalQuantity", 1L),
                            items = items,
                            status = obj.optString("status", "ACTIVE"),
                            createdAt = Timestamp.now(),
                            updatedAt = Timestamp.now()
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun persistMenuItems(context: Context, items: List<MenuItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("userId", item.userId)
                    put("name", item.name)
                    put("category", item.category)
                    put("price", item.price)
                    put("isVeg", item.isVeg)
                    put("isAvailable", item.isAvailable)
                }
            )
        }
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LOCAL_MENU_JSON, arr.toString())
            .apply()
    }

    private fun decodeMenuItems(jsonStr: String?): List<MenuItem> {
        if (jsonStr.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        MenuItem(
                            id = obj.optString("id"),
                            userId = obj.optString("userId", RestaurantInfo.APPROVED_USER_ID),
                            name = obj.optString("name"),
                            category = obj.optString("category", MenuCategories.CHICKEN_SHAWARMA),
                            price = obj.optLong("price", 100L),
                            isVeg = obj.optBoolean("isVeg", false),
                            isAvailable = obj.optBoolean("isAvailable", true)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
