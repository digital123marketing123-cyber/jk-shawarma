package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.MenuItem
import com.example.data.model.OrderLineItem
import com.example.data.model.OrderRecord
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class PosRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id)),
        auth = Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeOrders(userId: String): Flow<List<OrderRecord>> {
        val path = "users/$userId/orders"
        return db.collection("users")
            .document(userId)
            .collection("orders")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { querySnapshot ->
                querySnapshot.documents
                    .mapNotNull { OrderRecord.fromSnapshot(it) }
                    .sortedWith(
                        compareByDescending<OrderRecord> { it.dateKey }
                            .thenByDescending { it.tokenNumber }
                            .thenByDescending { it.createdAt ?: Timestamp(0, 0) }
                    )
            }
            .catch { error ->
                val firestoreEx = generateSequence(error) { it.cause }
                    .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
                    .firstOrNull()
                val actualException = firestoreEx ?: (error as? Exception) ?: RuntimeException(error)
                handleFirestoreError(actualException, OperationType.LIST, path)
                throw actualException
            }
    }

    fun observeCustomMenuItems(userId: String): Flow<List<MenuItem>> {
        val path = "users/$userId/menu_items"
        return db.collection("users")
            .document(userId)
            .collection("menu_items")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { querySnapshot ->
                querySnapshot.documents.mapNotNull { MenuItem.fromSnapshot(it) }
            }
            .catch { error ->
                val firestoreEx = generateSequence(error) { it.cause }
                    .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
                    .firstOrNull()
                val actualException = firestoreEx ?: (error as? Exception) ?: RuntimeException(error)
                handleFirestoreError(actualException, OperationType.LIST, path)
                throw actualException
            }
    }

    suspend fun createOrder(
        tokenNumber: Long,
        dateKey: String,
        dateDisplay: String,
        timeDisplay: String,
        customerPhone: String,
        customerName: String,
        orderType: String,
        paymentMethod: String,
        subtotalAmount: Long,
        discountAmount: Long,
        discountLabel: String,
        totalAmount: Long,
        items: List<OrderLineItem>,
        status: String = "ACTIVE",
        orderId: String = "ord_${UUID.randomUUID().toString().replace("-", "").take(20)}"
    ): Result<OrderRecord> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val totalQty = items.sumOf { it.quantity }.coerceAtLeast(1L)
        val record = OrderRecord(
            id = orderId,
            userId = uid,
            tokenNumber = tokenNumber,
            dateKey = dateKey,
            dateDisplay = dateDisplay,
            timeDisplay = timeDisplay,
            customerPhone = customerPhone,
            customerName = customerName,
            orderType = orderType,
            paymentMethod = paymentMethod,
            subtotalAmount = subtotalAmount,
            discountAmount = discountAmount,
            discountLabel = discountLabel,
            totalAmount = totalAmount,
            totalQuantity = totalQty,
            items = items,
            status = status,
            createdAt = Timestamp.now(),
            updatedAt = Timestamp.now()
        )

        val docRef = db.collection("users").document(uid).collection("orders").document(orderId)
        return try {
            docRef.set(record.toCreateMap(uid)).await()
            Result.success(record)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getOrderById(targetUserId: String, orderId: String): Result<OrderRecord> {
        val docRef = db.collection("users").document(targetUserId).collection("orders").document(orderId)
        return try {
            val snapshot = docRef.get().await()
            val order = OrderRecord.fromSnapshot(snapshot)
                ?: return Result.failure(NoSuchElementException("Order $orderId not found"))
            Result.success(order)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: String,
        customerPhone: String? = null,
        paymentMethod: String? = null
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users").document(uid).collection("orders").document(orderId)
        val updates = mutableMapOf<String, Any>(
            "status" to newStatus,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (customerPhone != null) {
            updates["customerPhone"] = customerPhone.trim().take(20)
        }
        if (paymentMethod != null) {
            updates["paymentMethod"] = paymentMethod
        }
        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteOrder(orderId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users").document(uid).collection("orders").document(orderId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun saveMenuItem(item: MenuItem, isExistingOverride: Boolean = false): Result<MenuItem> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = item.id.ifBlank {
            "item_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        }
        val finalItem = item.copy(id = cleanId, userId = uid)
        val docRef = db.collection("users").document(uid).collection("menu_items").document(cleanId)
        return try {
            if (isExistingOverride) {
                val snap = docRef.get().await()
                if (snap.exists()) {
                    docRef.update(finalItem.toUpdateMap()).await()
                } else {
                    docRef.set(finalItem.toCreateMap(uid)).await()
                }
            } else {
                docRef.set(finalItem.toCreateMap(uid)).await()
            }
            Result.success(finalItem)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }
}
