package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MenuCategories
import com.example.data.model.RestaurantInfo
import com.example.ui.CategorySalesSummary
import com.example.ui.PosCheckoutFormState
import com.example.ui.PosViewModel
import com.example.ui.SettlementPeriod
import com.example.ui.SettlementSummary
import com.example.ui.theme.CrownGold
import com.example.ui.theme.HalalGreen
import com.example.ui.theme.ShawarmaOrange
import com.example.ui.theme.WhatsAppGreen
import com.example.util.ReceiptShareHelper

@Composable
fun SettlementReportScreen(
    settlement: SettlementSummary,
    formState: PosCheckoutFormState,
    viewModel: PosViewModel
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settlement_report_lazy_column"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "settlement_header") {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assessment,
                        contentDescription = "Settlement Report",
                        tint = CrownGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "FINAL SETTLEMENT REPORT",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = CrownGold
                        )
                        Text(
                            text = "${RestaurantInfo.FULL_NAME} • ${settlement.periodLabel}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Period Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SettlementPeriod.entries.forEach { period ->
                        FilterChip(
                            selected = formState.settlementPeriod == period,
                            onClick = { viewModel.selectSettlementPeriod(period) },
                            label = { Text(period.label, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ShawarmaOrange,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("settlement_period_${period.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // Top KPI Summary Grid
        item(key = "kpi_summary_grid") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SettlementKpiCard(
                        title = "NET TOTAL SALES",
                        value = "₹${settlement.totalRevenue}",
                        subtitle = "${settlement.totalOrdersCount} Valid Orders",
                        accentColor = CrownGold,
                        icon = Icons.Default.AccountBalanceWallet,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settlement_total_sales_card")
                    )
                    SettlementKpiCard(
                        title = "PRODUCTS SOLD",
                        value = "${settlement.totalProductsSold} Qty",
                        subtitle = "${settlement.productBreakdown.size} Distinct Items",
                        accentColor = ShawarmaOrange,
                        icon = Icons.Default.Fastfood,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settlement_products_sold_card")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SettlementKpiCard(
                        title = "CASH COLLECTION",
                        value = "₹${settlement.cashAmount}",
                        subtitle = "${settlement.cashOrderCount} Cash Orders",
                        accentColor = HalalGreen,
                        icon = Icons.Default.Payments,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settlement_cash_card")
                    )
                    SettlementKpiCard(
                        title = "ONLINE / UPI",
                        value = "₹${settlement.upiAmount}",
                        subtitle = "${settlement.upiOrderCount} Online Orders",
                        accentColor = WhatsAppGreen,
                        icon = Icons.Default.QrCode2,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settlement_upi_card")
                    )
                }
            }
        }

        // Detailed Payment Breakdown Card (Cash vs UPI vs Other vs Discounts)
        item(key = "payment_breakdown_card") {
            val totalRevDenom = settlement.totalRevenue.coerceAtLeast(1L).toFloat()
            val cashRatio = (settlement.cashAmount.toFloat() / totalRevDenom).coerceIn(0f, 1f)
            val upiRatio = (settlement.upiAmount.toFloat() / totalRevDenom).coerceIn(0f, 1f)
            val otherRatio = (settlement.otherAmount.toFloat() / totalRevDenom).coerceIn(0f, 1f)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CrownGold.copy(alpha = 0.35f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "PAYMENT MODE SETTLEMENT (CASH VS ONLINE)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = CrownGold
                    )

                    PaymentBreakdownBarRow(
                        label = "💵 Cash Payments (${settlement.cashOrderCount} tokens)",
                        amount = settlement.cashAmount,
                        progress = if (settlement.totalRevenue > 0L) cashRatio else 0f,
                        barColor = HalalGreen
                    )

                    PaymentBreakdownBarRow(
                        label = "📱 Online / UPI Payments (${settlement.upiOrderCount} tokens)",
                        amount = settlement.upiAmount,
                        progress = if (settlement.totalRevenue > 0L) upiRatio else 0f,
                        barColor = ShawarmaOrange
                    )

                    if (settlement.otherAmount > 0L || settlement.otherOrderCount > 0) {
                        PaymentBreakdownBarRow(
                            label = "💳 Other / Card Payments (${settlement.otherOrderCount} tokens)",
                            amount = settlement.otherAmount,
                            progress = if (settlement.totalRevenue > 0L) otherRatio else 0f,
                            barColor = CrownGold
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Gross Subtotal (Before Discounts)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${settlement.totalSubtotal}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Total Discounts Given",
                            style = MaterialTheme.typography.bodyMedium,
                            color = HalalGreen
                        )
                        Text(
                            text = "-₹${settlement.totalDiscountAmount}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = HalalGreen
                        )
                    }
                }
            }
        }

        // Category-Wise & Product-Wise Sales Detail Header
        item(key = "category_wise_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Category,
                    contentDescription = "Category Wise Sales",
                    tint = ShawarmaOrange
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "CATEGORY-WISE & PRODUCT SALES DETAIL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = CrownGold
                    )
                    Text(
                        text = "Exact quantity sold and revenue per category & individual menu item",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (settlement.categoryBreakdown.isEmpty()) {
            item(key = "empty_settlement_card") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "No sales recorded for ${settlement.period.label}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Generate order tokens from the New Token tab to see live category-wise and product-wise sales settlement details.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(
                items = settlement.categoryBreakdown,
                key = { it.category }
            ) { categorySummary ->
                CategorySettlementDetailCard(categorySummary = categorySummary)
            }
        }

        // Share Settlement Report on WhatsApp Directly
        item(key = "share_settlement_card") {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, WhatsAppGreen.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "SHARE SETTLEMENT REPORT TO WHATSAPP",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = WhatsAppGreen
                    )
                    Text(
                        text = "Enter owner or manager WhatsApp number to send the complete category & product settlement summary.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = formState.settlementWhatsAppPhone,
                        onValueChange = viewModel::updateSettlementWhatsAppPhone,
                        label = { Text("WhatsApp Mobile Number (+91)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Owner Mobile Number",
                                tint = WhatsAppGreen
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settlement_whatsapp_phone_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val reportText = ReceiptShareHelper.buildSettlementReportText(settlement)
                                ReceiptShareHelper.copyToClipboard(context, "Settlement Report", reportText)
                            },
                            modifier = Modifier
                                .weight(0.9f)
                                .height(50.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Settlement Report",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy")
                        }

                        Button(
                            onClick = {
                                val reportText = ReceiptShareHelper.buildSettlementReportText(settlement)
                                ReceiptShareHelper.shareToWhatsAppDirect(
                                    context = context,
                                    rawPhoneInput = formState.settlementWhatsAppPhone,
                                    message = reportText
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1.6f)
                                .height(50.dp)
                                .testTag("share_settlement_whatsapp_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Send Settlement on WhatsApp"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Send Report on WhatsApp",
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }

        item(key = "settlement_footer_credit") {
            Text(
                text = RestaurantInfo.DEVELOPER_CREDIT,
                style = MaterialTheme.typography.labelLarge,
                color = CrownGold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun SettlementKpiCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = accentColor
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PaymentBreakdownBarRow(
    label: String,
    amount: Long,
    progress: Float,
    barColor: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "₹$amount (${(progress * 100).toInt()}%)",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                color = barColor
            )
        }
        LinearProgressIndicator(
            progress = { progress },
            color = barColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
        )
    }
}

@Composable
private fun CategorySettlementDetailCard(
    categorySummary: CategorySalesSummary
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ShawarmaOrange.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Category Title & Summary Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(ShawarmaOrange)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = MenuCategories.displayTitle(categorySummary.category),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    color = CrownGold.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${categorySummary.totalQuantitySold} Sold • ₹${categorySummary.totalRevenue}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrownGold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

            // Table Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "PRODUCT NAME",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "QTY SOLD",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(74.dp),
                    textAlign = TextAlign.End
                )
                Text(
                    text = "REVENUE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(82.dp),
                    textAlign = TextAlign.End
                )
            }

            categorySummary.products.forEach { product ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "@ ₹${product.unitPrice} each",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }
                    Text(
                        text = "${product.quantitySold} Qty",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = HalalGreen,
                        modifier = Modifier.width(74.dp),
                        textAlign = TextAlign.End
                    )
                    Text(
                        text = "₹${product.totalRevenue}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrownGold,
                        modifier = Modifier.width(82.dp),
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }
}
