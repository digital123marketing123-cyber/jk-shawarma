package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val JkDarkColorScheme = darkColorScheme(
    primary = ShawarmaOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A2108),
    onPrimaryContainer = CrownGoldSoft,
    secondary = CrownGold,
    onSecondary = Color(0xFF231900),
    secondaryContainer = Color(0xFF3D2E05),
    onSecondaryContainer = CrownGoldSoft,
    tertiary = HalalGreen,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF0A3B28),
    onTertiaryContainer = Color(0xFFA7F3D0),
    background = GrillDarkBg,
    onBackground = CreamTextPrimary,
    surface = GrillSurface,
    onSurface = CreamTextPrimary,
    surfaceVariant = GrillSurfaceVariant,
    onSurfaceVariant = WarmTextSecondary,
    outline = GrillCardBorder,
    error = ErrorCrimson,
    onError = Color.White
)

private val JkLightColorScheme = lightColorScheme(
    primary = ShawarmaOrangeDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBC8),
    onPrimaryContainer = Color(0xFF351000),
    secondary = Color(0xFFB27D00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE08B),
    onSecondaryContainer = Color(0xFF261900),
    tertiary = Color(0xFF0F8A5F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC8F7E2),
    onTertiaryContainer = Color(0xFF002114),
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = Color(0xFFD8C2B0),
    error = Color(0xFFC62828),
    onError = Color.White
)

val JkShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) JkDarkColorScheme else JkLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = JkShapes,
        content = content
    )
}
