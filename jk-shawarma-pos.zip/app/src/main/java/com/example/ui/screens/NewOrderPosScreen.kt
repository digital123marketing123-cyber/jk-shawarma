package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MenuCategories
import com.example.data.model.MenuItem
import com.example.data.model.OrderRecord
import com.example.data.model.RestaurantInfo
import com.example.ui.DiscountType
import com.example.ui.PosCheckoutFormState
import com.example.ui.PosViewModel
import com.example.ui.components.JkBrandLogoBanner
import com.example.ui.theme.CrownGold
import com.example.ui.theme.HalalGreen
import com.example.ui.theme.NonVegRed
import com.example.ui.theme.ShawarmaOrange
import com.example.ui.theme.VegGreen
import com.example.ui.theme.WhatsAppGreen
import com.example.util.ReceiptShareHelper

@Composable
fun NewOrderPosScreen(
    viewModel: PosViewModel,
    formState: PosCheckoutFormState,
    menuCatalog: List<MenuItem>,
    nextTokenNumber: Long
) {
    val context = LocalContext.current
    var isCheckoutExpanded by remember { mutableStateOf(false) }

    val filteredMenu = remember(menuCatalog, formState.selectedCategory, formState.searchQuery, formState.vegOnly) {
        menuCatalog.filter { item ->
            val matchesCategory = formState.selectedCategory == "ALL" || item.category == formState.selectedCategory
            val matchesSearch = formState.searchQuery.isBlank() ||
                item.name.contains(formState.searchQuery.trim(), ignoreCase = true) ||
                item.category.contains(formState.searchQuery.trim(), ignoreCase = true)
            val matchesVeg = !formState.vegOnly || item.isVeg
            matchesCategory && matchesSearch && matchesVeg && item.isAvailable
        }
    }

    val groupedMenu = remember(filteredMenu) {
        val order = MenuCategories.ALL
        filteredMenu.groupBy { it.category }
            .entries
            .sortedBy { entry ->
                val idx = order.indexOf(entry.key)
                if (idx == -1) 999 else idx
            }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideTablet = maxWidth >= 760.dp

        if (isWideTablet) {
            // Canonical Two-Pane POS Layout for Tablets / Foldables
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.25f)
                        .fillMaxHeight()
                ) {
                    PosMenuPane(
                        formState = formState,
                        nextTokenNumber = nextTokenNumber,
                        groupedMenu = groupedMenu,
                        onSelectCategory = viewModel::selectCategory,
                        onSearchQueryChange = viewModel::updateSearchQuery,
                        onToggleVegOnly = viewModel::toggleVegOnly,
                        onAddItem = viewModel::addOrIncrementItem,
                        onDecrementItem = viewModel::decrementItem
                    )
                }

                Card(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    CheckoutSummaryPanel(
                        formState = formState,
                        nextTokenNumber = nextTokenNumber,
                        viewModel = viewModel,
                        onOrderCreated = { createdOrder, autoWhatsApp ->
                            if (autoWhatsApp) {
                                val msg = ReceiptShareHelper.buildOrderReceiptText(createdOrder)
                                ReceiptShareHelper.shareToWhatsAppDirect(
                                    context = context,
                                    rawPhoneInput = createdOrder.customerPhone,
                                    message = msg
                                )
                            }
                        }
                    )
                }
            }
        } else {
            // Handheld Mobile POS Layout with Sticky Checkout Drawer
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f)) {
                    PosMenuPane(
                        formState = formState,
                        nextTokenNumber = nextTokenNumber,
                        groupedMenu = groupedMenu,
                        onSelectCategory = viewModel::selectCategory,
                        onSearchQueryChange = viewModel::updateSearchQuery,
                        onToggleVegOnly = viewModel::toggleVegOnly,
                        onAddItem = viewModel::addOrIncrementItem,
                        onDecrementItem = viewModel::decrementItem
                    )
                }

                // Bottom Sticky Cart & Token Generation Bar
                MobileCheckoutDrawer(
                    formState = formState,
                    nextTokenNumber = nextTokenNumber,
                    isExpanded = isCheckoutExpanded,
                    onToggleExpand = { isCheckoutExpanded = !isCheckoutExpanded },
                    viewModel = viewModel,
                    onOrderCreated = { createdOrder, autoWhatsApp ->
                        isCheckoutExpanded = false
                        if (autoWhatsApp) {
                            val msg = ReceiptShareHelper.buildOrderReceiptText(createdOrder)
                            ReceiptShareHelper.shareToWhatsAppDirect(
                                context = context,
                                rawPhoneInput = createdOrder.customerPhone,
                                message = msg
                            )
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun PosMenuPane(
    formState: PosCheckoutFormState,
    nextTokenNumber: Long,
    groupedMenu: List<Map.Entry<String, List<MenuItem>>>,
    onSelectCategory: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleVegOnly: () -> Unit,
    onAddItem: (MenuItem) -> Unit,
    onDecrementItem: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("pos_menu_lazy_column"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "brand_banner") {
            JkBrandLogoBanner(compact = false)
        }

        item(key = "token_and_search_bar") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Live Token Counter Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, CrownGold.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = "Next Token Number",
                            tint = ShawarmaOrange,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "NEXT ORDER TOKEN SERIAL",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "TOKEN ${ReceiptShareHelper.formatTokenSerial(nextTokenNumber)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = CrownGold,
                                modifier = Modifier.testTag("next_token_badge_text")
                            )
                        }
                    }

                    Surface(
                        color = ShawarmaOrange.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (formState.totalCartQuantity > 0L) {
                                "${formState.totalCartQuantity} Items • ₹${formState.finalPayableAmount}"
                            } else {
                                "Tap + to Add Items"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = CrownGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                // Search & Veg Filter Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = formState.searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search Shawarma, Grill, Roti...") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search Menu"
                            )
                        },
                        trailingIcon = {
                            if (formState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("menu_search_input")
                    )

                    FilterChip(
                        selected = formState.vegOnly,
                        onClick = onToggleVegOnly,
                        label = { Text("VEG ONLY", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VegGreen.copy(alpha = 0.25f),
                            selectedLabelColor = HalalGreen
                        ),
                        modifier = Modifier.height(48.dp)
                    )
                }

                // Category Chips Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val categories = listOf("ALL") + MenuCategories.ALL
                    categories.forEach { cat ->
                        val isSelected = formState.selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectCategory(cat) },
                            label = {
                                Text(
                                    text = if (cat == "ALL") "ALL MENU (25)" else cat,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ShawarmaOrange,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("category_chip_${cat.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        }

        groupedMenu.forEach { (category, itemsInCategory) ->
            item(key = "header_$category") {
                CategorySectionBanner(title = MenuCategories.displayTitle(category))
            }

            items(items = itemsInCategory, key = { it.id }) { menuItem ->
                val qtyInCart = formState.cart[menuItem.id]?.quantity ?: 0L
                MenuItemPosCard(
                    item = menuItem,
                    quantityInCart = qtyInCart,
                    onIncrement = { onAddItem(menuItem) },
                    onDecrement = { onDecrementItem(menuItem.id) }
                )
            }
        }

        item(key = "bottom_credit_spacer") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = RestaurantInfo.DEVELOPER_CREDIT,
                    style = MaterialTheme.typography.labelLarge,
                    color = CrownGold.copy(alpha = 0.85f)
                )
            }
        }
    }
}

@Composable
private fun CategorySectionBanner(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(ShawarmaOrange)
                .padding(horizontal = 12.dp, vertical = 5.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = ShawarmaOrange.copy(alpha = 0.35f)
        )
    }
}

@Composable
private fun MenuItemPosCard(
    item: MenuItem,
    quantityInCart: Long,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    val isSelected = quantityInCart > 0L
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) ShawarmaOrange else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onIncrement() }
            .testTag("menu_item_card_${item.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                ShawarmaOrange.copy(alpha = 0.12f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Veg / Non-Veg Indian Food Standard Symbol
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .border(
                            1.5.dp,
                            if (item.isVeg) VegGreen else NonVegRed,
                            RoundedCornerShape(4.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (item.isVeg) VegGreen else NonVegRed)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "₹${item.price}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrownGold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            if (quantityInCart == 0L) {
                Button(
                    onClick = onIncrement,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ShawarmaOrange,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("add_item_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add ${item.name}",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ADD", fontWeight = FontWeight.ExtraBold)
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(ShawarmaOrange)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = onDecrement,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("dec_item_button_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Decrease ${item.name}",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = quantityInCart.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                        onClick = onIncrement,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("inc_item_button_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Increase ${item.name}",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MobileCheckoutDrawer(
    formState: PosCheckoutFormState,
    nextTokenNumber: Long,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    viewModel: PosViewModel,
    onOrderCreated: (OrderRecord, Boolean) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                color = CrownGold.copy(alpha = 0.45f),
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
            ),
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Summary Header Bar (Always Visible)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("toggle_checkout_drawer_bar"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(ShawarmaOrange.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCartCheckout,
                            contentDescription = "Order Cart",
                            tint = ShawarmaOrange
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Token ${ReceiptShareHelper.formatTokenSerial(nextTokenNumber)} • ${formState.totalCartQuantity} Items",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (formState.discountAmount > 0L) {
                                "Total: ₹${formState.finalPayableAmount} (Saved ₹${formState.discountAmount})"
                            } else {
                                "Total Payable: ₹${formState.finalPayableAmount} • ${formState.paymentMethod}"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = CrownGold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onToggleExpand,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isExpanded) MaterialTheme.colorScheme.surfaceVariant else ShawarmaOrange
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("expand_checkout_button")
                    ) {
                        Text(
                            text = if (isExpanded) "Hide" else "Checkout & WhatsApp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
                            contentDescription = "Expand Checkout"
                        )
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(470.dp)
                ) {
                    CheckoutSummaryPanel(
                        formState = formState,
                        nextTokenNumber = nextTokenNumber,
                        viewModel = viewModel,
                        onOrderCreated = onOrderCreated
                    )
                }
            }
        }
    }
}

@Composable
private fun CheckoutSummaryPanel(
    formState: PosCheckoutFormState,
    nextTokenNumber: Long,
    viewModel: PosViewModel,
    onOrderCreated: (OrderRecord, Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header with Clear Cart
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ReceiptLong,
                    contentDescription = "Order Token Invoice",
                    tint = CrownGold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TOKEN ${ReceiptShareHelper.formatTokenSerial(nextTokenNumber)} BILLING",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = CrownGold
                )
            }
            if (formState.cart.isNotEmpty()) {
                OutlinedButton(
                    onClick = viewModel::clearCart,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("clear_cart_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear Cart",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear", fontSize = 12.sp)
                }
            }
        }

        // Selected Cart Items List
        if (formState.cartItemsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Select menu items above to generate an order token & WhatsApp invoice.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                formState.cartItemsList.forEach { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = entry.menuItem.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${entry.quantity} x ₹${entry.menuItem.price}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "₹${entry.lineTotal}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrownGold
                        )
                    }
                }
            }
        }

        // Order Type Chips (TAKEAWAY / DINE_IN / PARCEL)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Order Type",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("TAKEAWAY", "DINE_IN", "PARCEL").forEach { type ->
                    FilterChip(
                        selected = formState.orderType == type,
                        onClick = { viewModel.updateOrderType(type) },
                        label = { Text(type.replace("_", " "), fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ShawarmaOrange,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Payment Method Selector (CASH / UPI / OTHER)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = "Payment Method",
                    tint = CrownGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Payment Method (Cash / UPI / Other)",
                    style = MaterialTheme.typography.labelLarge,
                    color = CrownGold
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "CASH" to "💵 CASH",
                    "UPI" to "📱 UPI / ONLINE",
                    "OTHER" to "💳 OTHER"
                ).forEach { (code, label) ->
                    FilterChip(
                        selected = formState.paymentMethod == code,
                        onClick = { viewModel.updatePaymentMethod(code) },
                        label = { Text(label, fontWeight = FontWeight.ExtraBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (code == "UPI") HalalGreen else ShawarmaOrange,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("payment_method_chip_${code.lowercase()}")
                    )
                }
            }

            if (formState.paymentMethod == "CASH" && formState.finalPayableAmount > 0L) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = formState.cashReceivedInput,
                        onValueChange = viewModel::updateCashReceivedInput,
                        label = { Text("Cash Received (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (formState.cashReceivedInput.isNotBlank()) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Return Change",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${formState.cashChangeToReturn}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = HalalGreen
                            )
                        }
                    }
                }
            }
        }

        // Discount Selector (None, 5%, 10%, 15%, 20%, Flat ₹)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocalOffer,
                    contentDescription = "Discount Option",
                    tint = ShawarmaOrange,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Discount Option",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    DiscountType.NONE to "No Discount",
                    DiscountType.PERCENT_5 to "5% OFF",
                    DiscountType.PERCENT_10 to "10% OFF",
                    DiscountType.PERCENT_15 to "15% OFF",
                    DiscountType.PERCENT_20 to "20% OFF",
                    DiscountType.FLAT_AMOUNT to "Flat ₹ OFF"
                ).forEach { (type, label) ->
                    FilterChip(
                        selected = formState.discountType == type,
                        onClick = { viewModel.selectDiscountType(type) },
                        label = { Text(label, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ShawarmaOrange,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("discount_chip_${type.name.lowercase()}")
                    )
                }
            }

            if (formState.discountType == DiscountType.FLAT_AMOUNT) {
                OutlinedTextField(
                    value = formState.customFlatDiscountInput,
                    onValueChange = viewModel::updateCustomFlatDiscount,
                    label = { Text("Enter Flat Discount Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("flat_discount_input")
                )
            }
        }

        // Customer Mobile Number for Direct WhatsApp Invoice Share
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Customer Mobile Number (WhatsApp Receipt CTA)",
                style = MaterialTheme.typography.labelLarge,
                color = WhatsAppGreen
            )
            OutlinedTextField(
                value = formState.customerPhone,
                onValueChange = viewModel::updateCustomerPhone,
                label = { Text("Enter Mobile Number (+91)") },
                placeholder = { Text("e.g. 9876543210") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Customer Phone",
                        tint = WhatsAppGreen
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_customer_phone_input")
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.toggleAutoShareWhatsApp(!formState.autoShareWhatsAppOnGenerate)
                    }
            ) {
                Checkbox(
                    checked = formState.autoShareWhatsAppOnGenerate,
                    onCheckedChange = viewModel::toggleAutoShareWhatsApp
                )
                Text(
                    text = "Launch WhatsApp directly when Token is generated",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Total Summary Box
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Subtotal (${formState.totalCartQuantity} items)")
                    Text("₹${formState.subtotalAmount}", fontWeight = FontWeight.Bold)
                }
                if (formState.discountAmount > 0L) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Discount (${formState.discountLabel})", color = HalalGreen)
                        Text("-₹${formState.discountAmount}", color = HalalGreen, fontWeight = FontWeight.Bold)
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL AMOUNT",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "₹${formState.finalPayableAmount}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = CrownGold
                    )
                }
            }
        }

        // Generate Token & Invoice Primary CTA Button
        Button(
            onClick = { viewModel.generateOrderToken(onOrderCreated) },
            enabled = formState.cart.isNotEmpty() && !formState.isSubmittingOrder,
            colors = ButtonDefaults.buttonColors(
                containerColor = ShawarmaOrange,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("generate_token_button")
        ) {
            Icon(
                imageVector = Icons.Default.ConfirmationNumber,
                contentDescription = "Generate Token"
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "GENERATE TOKEN ${ReceiptShareHelper.formatTokenSerial(nextTokenNumber)} (₹${formState.finalPayableAmount})",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp
            )
        }

        Text(
            text = RestaurantInfo.DEVELOPER_CREDIT,
            style = MaterialTheme.typography.labelLarge,
            color = CrownGold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
