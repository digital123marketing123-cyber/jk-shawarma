package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.OrderRecord
import com.example.data.model.RestaurantInfo
import com.example.ui.theme.CrownGold
import com.example.ui.theme.HalalGreen
import com.example.ui.theme.ShawarmaOrange
import com.example.ui.theme.WhatsAppGreen
import com.example.util.ReceiptShareHelper

/**
 * Recreates the exact JK Arabian Shawarma & Grill House Crown Logo + Halal Badge header
 * from the uploaded reference PDF menu.
 */
@Composable
fun JkBrandLogoBanner(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(
                    listOf(CrownGold.copy(alpha = 0.7f), ShawarmaOrange, CrownGold.copy(alpha = 0.7f))
                ),
                shape = RoundedCornerShape(18.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF16120E)
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = if (compact) 10.dp else 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left JK Crest Medallion (from PDF top-left)
                JkCrestMedallion()

                // Center Crown + JK ARABIAN SHAWARMA & GRILL HOUSE
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CrownVectorIcon(modifier = Modifier.size(width = 34.dp, height = 18.dp))
                            Text(
                                text = "JK",
                                fontSize = if (compact) 28.sp else 34.sp,
                                fontWeight = FontWeight.Black,
                                color = ShawarmaOrange,
                                lineHeight = 32.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.Start) {
                            Text(
                                text = "ARABIAN SHAWARMA",
                                fontSize = if (compact) 14.sp else 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrownGold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "— & GRILL HOUSE —",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                // Right HALAL green circle badge (from PDF top-right)
                HalalCircleBadge()
            }

            if (!compact) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Contact phone",
                            tint = ShawarmaOrange,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = RestaurantInfo.CONTACT,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CrownGold
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            tint = ShawarmaOrange,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "RTO Office Rd, Siddhardha Nagar, Kakinada",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.88f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CrownVectorIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.1f, h * 0.85f)
            lineTo(w * 0.05f, h * 0.3f)
            lineTo(w * 0.32f, h * 0.58f)
            lineTo(w * 0.5f, h * 0.15f)
            lineTo(w * 0.68f, h * 0.58f)
            lineTo(w * 0.95f, h * 0.3f)
            lineTo(w * 0.9f, h * 0.85f)
            close()
        }
        drawPath(path = path, color = CrownGold)
        drawCircle(color = CrownGold, radius = 3.dp.toPx(), center = Offset(w * 0.05f, h * 0.22f))
        drawCircle(color = CrownGold, radius = 3.5.dp.toPx(), center = Offset(w * 0.5f, h * 0.1f))
        drawCircle(color = CrownGold, radius = 3.dp.toPx(), center = Offset(w * 0.95f, h * 0.22f))
    }
}

@Composable
private fun JkCrestMedallion() {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF1F1712))
            .border(1.5.dp, CrownGold, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "👑",
                fontSize = 9.sp,
                lineHeight = 10.sp
            )
            Text(
                text = "JK",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = ShawarmaOrange,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
private fun HalalCircleBadge() {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(HalalGreen.copy(alpha = 0.14f))
            .border(1.5.dp, HalalGreen, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "حلال",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = HalalGreen,
                lineHeight = 12.sp
            )
            Text(
                text = "HALAL",
                fontSize = 8.sp,
                fontWeight = FontWeight.ExtraBold,
                color = HalalGreen,
                lineHeight = 9.sp
            )
        }
    }
}

/**
 * Generated Token & Invoice Receipt Modal Dialog.
 * Displays:
 * - Top: Restaurant Name, Date, Order Time, Token Serial Number
 * - Middle: Ordered Menu Items with Qty, Unit Price, Line Total
 * - Bottom: Total Amount, Payment Method, Discount, and "Developed by Johnny Ads"
 * - Call-to-Action: Enter Mobile Number & Share Receipt directly to WhatsApp
 */
@Composable
fun TokenReceiptDialog(
    order: OrderRecord,
    onDismiss: () -> Unit,
    onUpdatePhone: (String) -> Unit,
    onMarkCompleted: () -> Unit,
    onCancelOrder: () -> Unit
) {
    val context = LocalContext.current
    var phoneInput by remember(order.id) { mutableStateOf(order.customerPhone) }
    val tokenSerialStr = ReceiptShareHelper.formatTokenSerial(order.tokenNumber)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                // Modal Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Token Generated",
                            tint = HalalGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ORDER TOKEN & INVOICE",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrownGold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_receipt_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close receipt preview"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Printable Receipt Paper Container
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, CrownGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    color = Color(0xFF15110E),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top: Restaurant Name & Logo
                        CrownVectorIcon(modifier = Modifier.size(width = 36.dp, height = 18.dp))
                        Text(
                            text = RestaurantInfo.NAME,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = ShawarmaOrange,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${RestaurantInfo.SUBTITLE} • HALAL",
                            style = MaterialTheme.typography.labelLarge,
                            color = CrownGold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = RestaurantInfo.ADDRESS,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.78f),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Contact: ${RestaurantInfo.CONTACT}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrownGold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Prominent Token Serial Number Banner
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(ShawarmaOrange.copy(alpha = 0.18f))
                                .border(1.dp, ShawarmaOrange, RoundedCornerShape(12.dp))
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "TOKEN SERIAL NUMBER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CrownGold,
                                    letterSpacing = 1.2.sp
                                )
                                Text(
                                    text = "TOKEN $tokenSerialStr",
                                    style = MaterialTheme.typography.displaySmall,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    modifier = Modifier.testTag("receipt_token_serial_text")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Date, Order Time, Type & Payment Status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Date: ${order.dateDisplay}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Time: ${order.timeDisplay}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Type: ${order.orderType.replace("_", " ")}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrownGold
                            )
                            Text(
                                text = "Status: ${order.status}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (order.status == "CANCELLED") MaterialTheme.colorScheme.error else HalalGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Menu Items Table Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "MENU ITEM",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrownGold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "QTY x RATE",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrownGold,
                                modifier = Modifier.width(86.dp),
                                textAlign = TextAlign.End
                            )
                            Text(
                                text = "AMT",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrownGold,
                                modifier = Modifier.width(64.dp),
                                textAlign = TextAlign.End
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        order.items.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = item.category,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = "${item.quantity} x ₹${item.unitPrice}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier.width(86.dp),
                                    textAlign = TextAlign.End
                                )
                                Text(
                                    text = "₹${item.lineTotal}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CrownGold,
                                    modifier = Modifier.width(64.dp),
                                    textAlign = TextAlign.End
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Subtotal, Discount, Payment Mode & Grand Total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Subtotal (${order.totalQuantity} items)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Text(
                                text = "₹${order.subtotalAmount}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                        }

                        if (order.discountAmount > 0L) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Discount ${if (order.discountLabel.isNotBlank()) "(${order.discountLabel})" else ""}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = HalalGreen
                                )
                                Text(
                                    text = "-₹${order.discountAmount}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = HalalGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CrownGold.copy(alpha = 0.14f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL AMOUNT",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Payment Mode: ${order.paymentMethod}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CrownGold
                                )
                            }
                            Text(
                                text = "₹${order.totalAmount}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Black,
                                color = CrownGold,
                                modifier = Modifier.testTag("receipt_total_amount_text")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Mandatory Footer Credit: Developed by Johnny Ads
                        Text(
                            text = RestaurantInfo.DEVELOPER_CREDIT,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrownGold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("receipt_developer_credit_text")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Direct WhatsApp Call-to-Action Section
                Text(
                    text = "Share Invoice Receipt to WhatsApp Directly",
                    style = MaterialTheme.typography.labelLarge,
                    color = WhatsAppGreen
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = {
                        phoneInput = it.filter { ch -> ch.isDigit() || ch == '+' }.take(15)
                        onUpdatePhone(phoneInput)
                    },
                    label = { Text("Enter Customer Mobile Number (+91)") },
                    placeholder = { Text("e.g. 9876543210") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Customer Mobile"
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("receipt_whatsapp_phone_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val updatedOrder = order.copy(customerPhone = phoneInput.trim())
                        val receiptMessage = ReceiptShareHelper.buildOrderReceiptText(updatedOrder)
                        ReceiptShareHelper.shareToWhatsAppDirect(
                            context = context,
                            rawPhoneInput = phoneInput,
                            message = receiptMessage
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WhatsAppGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("share_whatsapp_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share on WhatsApp"
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (phoneInput.isNotBlank()) {
                            "Send Receipt on WhatsApp (${phoneInput.trim()})"
                        } else {
                            "Share Receipt on WhatsApp"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val updatedOrder = order.copy(customerPhone = phoneInput.trim())
                            val text = ReceiptShareHelper.buildOrderReceiptText(updatedOrder)
                            ReceiptShareHelper.copyToClipboard(context, "Token $tokenSerialStr", text)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("copy_receipt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Receipt",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Invoice")
                    }

                    if (order.status == "ACTIVE") {
                        Button(
                            onClick = {
                                onMarkCompleted()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ShawarmaOrange
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("mark_completed_button")
                        ) {
                            Text("Complete Order")
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Text("Done")
                        }
                    }
                }
            }
        }
    }
}
