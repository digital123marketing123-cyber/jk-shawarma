package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.LocalPosSessionStore
import com.example.data.model.DefaultMenuCatalog
import com.example.data.model.MenuCategories
import com.example.data.model.MenuItem
import com.example.data.model.OrderLineItem
import com.example.data.model.OrderRecord
import com.example.data.repository.PosRepository
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class DiscountType {
    NONE,
    PERCENT_5,
    PERCENT_10,
    PERCENT_15,
    PERCENT_20,
    FLAT_AMOUNT
}

enum class SettlementPeriod(val label: String) {
    TODAY("Today"),
    YESTERDAY("Yesterday"),
    LAST_7_DAYS("Last 7 Days"),
    THIS_MONTH("This Month"),
    ALL_TIME("All Time")
}

data class CartEntry(
    val menuItem: MenuItem,
    val quantity: Long
) {
    val lineTotal: Long get() = menuItem.price * quantity
}

data class ProductSalesSummary(
    val itemId: String,
    val name: String,
    val category: String,
    val unitPrice: Long,
    val quantitySold: Long,
    val totalRevenue: Long
)

data class CategorySalesSummary(
    val category: String,
    val totalQuantitySold: Long,
    val totalRevenue: Long,
    val revenueSharePercent: Float,
    val products: List<ProductSalesSummary>
)

data class SettlementSummary(
    val period: SettlementPeriod,
    val periodLabel: String,
    val totalRevenue: Long,
    val totalSubtotal: Long,
    val totalDiscountAmount: Long,
    val totalOrdersCount: Int,
    val cancelledOrdersCount: Int,
    val totalProductsSold: Long,
    val cashAmount: Long,
    val cashOrderCount: Int,
    val upiAmount: Long,
    val upiOrderCount: Int,
    val otherAmount: Long,
    val otherOrderCount: Int,
    val categoryBreakdown: List<CategorySalesSummary>,
    val productBreakdown: List<ProductSalesSummary>
)

data class PosCheckoutFormState(
    val selectedCategory: String = "ALL",
    val searchQuery: String = "",
    val vegOnly: Boolean = false,
    val cart: Map<String, CartEntry> = emptyMap(),
    val customerPhone: String = "",
    val customerName: String = "",
    val orderType: String = "TAKEAWAY",
    val paymentMethod: String = "CASH",
    val cashReceivedInput: String = "",
    val discountType: DiscountType = DiscountType.NONE,
    val customFlatDiscountInput: String = "",
    val customTokenOverrideInput: String = "",
    val autoShareWhatsAppOnGenerate: Boolean = false,
    val isSubmittingOrder: Boolean = false,
    val activeReceiptOrder: OrderRecord? = null,
    val settlementPeriod: SettlementPeriod = SettlementPeriod.TODAY,
    val settlementWhatsAppPhone: String = "8688553379",
    val statusBannerMessage: String? = null
) {
    val cartItemsList: List<CartEntry>
        get() = cart.values.sortedBy { it.menuItem.name }

    val totalCartQuantity: Long
        get() = cart.values.sumOf { it.quantity }

    val subtotalAmount: Long
        get() = cart.values.sumOf { it.lineTotal }

    val discountAmount: Long
        get() = when (discountType) {
            DiscountType.NONE -> 0L
            DiscountType.PERCENT_5 -> (subtotalAmount * 5L) / 100L
            DiscountType.PERCENT_10 -> (subtotalAmount * 10L) / 100L
            DiscountType.PERCENT_15 -> (subtotalAmount * 15L) / 100L
            DiscountType.PERCENT_20 -> (subtotalAmount * 20L) / 100L
            DiscountType.FLAT_AMOUNT -> (customFlatDiscountInput.toLongOrNull() ?: 0L)
                .coerceIn(0L, subtotalAmount)
        }

    val discountLabel: String
        get() = when (discountType) {
            DiscountType.NONE -> ""
            DiscountType.PERCENT_5 -> "5% OFF"
            DiscountType.PERCENT_10 -> "10% OFF"
            DiscountType.PERCENT_15 -> "15% OFF"
            DiscountType.PERCENT_20 -> "20% OFF"
            DiscountType.FLAT_AMOUNT -> if (discountAmount > 0L) "Flat ₹$discountAmount OFF" else ""
        }

    val finalPayableAmount: Long
        get() = (subtotalAmount - discountAmount).coerceAtLeast(0L)

    val cashChangeToReturn: Long
        get() {
            val tendered = cashReceivedInput.toLongOrNull() ?: 0L
            return (tendered - finalPayableAmount).coerceAtLeast(0L)
        }
}

class PosViewModel(
    private val appContext: Application,
    private val currentUserId: String,
    private val isCloudAuthenticated: Boolean
) : AndroidViewModel(appContext) {

    init {
        LocalPosSessionStore.ensureInitialized(appContext)
    }

    private val databaseId: String = appContext.getString(R.string.firestore_database_id)
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(databaseId)
    private val repository: PosRepository = PosRepository(db)

    private val _formState = MutableStateFlow(PosCheckoutFormState())
    val formState: StateFlow<PosCheckoutFormState> = _formState.asStateFlow()

    // Strictly auth-gated Firestore streams: only query Firestore when Firebase.auth.currentUser != null
    private val cloudOrdersFlow: Flow<List<OrderRecord>> =
        if (isCloudAuthenticated && Firebase.auth.currentUser != null) {
            repository.observeOrders(currentUserId)
        } else {
            flowOf(emptyList())
        }

    private val cloudMenuFlow: Flow<List<MenuItem>> =
        if (isCloudAuthenticated && Firebase.auth.currentUser != null) {
            repository.observeCustomMenuItems(currentUserId)
        } else {
            flowOf(emptyList())
        }

    // Two-tier Flow error handling combining cloud + local session orders
    val ordersState: StateFlow<UiState<List<OrderRecord>>> =
        combine(cloudOrdersFlow, LocalPosSessionStore.localOrders) { cloudList, localList ->
            val mergedById = (localList + cloudList).associateBy { it.id }
            mergedById.values.sortedWith(
                compareByDescending<OrderRecord> { it.dateKey }
                    .thenByDescending { it.tokenNumber }
                    .thenByDescending { it.createdAt ?: Timestamp(0, 0) }
            )
        }
            .map<List<OrderRecord>, UiState<List<OrderRecord>>> { UiState.Success(it) }
            .catch { error ->
                Log.w(TAG, "Error observing orders", error)
                emit(UiState.Success(LocalPosSessionStore.localOrders.value))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Success(LocalPosSessionStore.localOrders.value)
            )

    private val customMenuState: StateFlow<UiState<List<MenuItem>>> =
        combine(cloudMenuFlow, LocalPosSessionStore.localCustomMenu) { cloudItems, localItems ->
            (localItems + cloudItems).associateBy { it.id }.values.toList()
        }
            .map<List<MenuItem>, UiState<List<MenuItem>>> { UiState.Success(it) }
            .catch { error ->
                Log.w(TAG, "Error observing custom menu items", error)
                emit(UiState.Success(LocalPosSessionStore.localCustomMenu.value))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Success(LocalPosSessionStore.localCustomMenu.value)
            )

    // Merged catalog: all 25 official JK Arabian Shawarma PDF items + user custom overrides/items
    val mergedMenuCatalog: StateFlow<List<MenuItem>> = customMenuState
        .map { state ->
            val customList = (state as? UiState.Success)?.data ?: emptyList()
            val customById = customList.associateBy { it.id }
            val updatedDefaults = DefaultMenuCatalog.ITEMS.map { defaultItem ->
                customById[defaultItem.id] ?: defaultItem
            }
            val defaultIds = DefaultMenuCatalog.ITEMS.map { it.id }.toSet()
            val extraCustomItems = customList.filter { it.id !in defaultIds }
            updatedDefaults + extraCustomItems
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = DefaultMenuCatalog.ITEMS
        )

    // Auto-incremented next token number for today
    val nextTokenNumber: StateFlow<Long> = combine(ordersState, _formState) { ordState, form ->
        val manualOverride = form.customTokenOverrideInput.toLongOrNull()
        if (manualOverride != null && manualOverride >= 1L) {
            manualOverride
        } else {
            val todayKey = currentDateKey()
            val orders = (ordState as? UiState.Success)?.data ?: emptyList()
            val todayMax = orders.filter { it.dateKey == todayKey }.maxOfOrNull { it.tokenNumber } ?: 0L
            todayMax + 1L
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = 1L
    )

    // Live Settlement Report computation
    val settlementSummary: StateFlow<SettlementSummary> = combine(ordersState, _formState) { ordState, form ->
        val allOrders = (ordState as? UiState.Success)?.data ?: emptyList()
        computeSettlement(allOrders, form.settlementPeriod)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = computeSettlement(emptyList(), SettlementPeriod.TODAY)
    )

    fun selectCategory(category: String) {
        _formState.update { it.copy(selectedCategory = category) }
    }

    fun updateSearchQuery(query: String) {
        _formState.update { it.copy(searchQuery = query) }
    }

    fun toggleVegOnly() {
        _formState.update { it.copy(vegOnly = !it.vegOnly) }
    }

    fun addOrIncrementItem(item: MenuItem) {
        if (!item.isAvailable) return
        _formState.update { state ->
            val currentQty = state.cart[item.id]?.quantity ?: 0L
            val updatedCart = state.cart.toMutableMap()
            updatedCart[item.id] = CartEntry(menuItem = item, quantity = (currentQty + 1L).coerceAtMost(500L))
            state.copy(cart = updatedCart)
        }
    }

    fun decrementItem(itemId: String) {
        _formState.update { state ->
            val existing = state.cart[itemId] ?: return@update state
            val updatedCart = state.cart.toMutableMap()
            if (existing.quantity <= 1L) {
                updatedCart.remove(itemId)
            } else {
                updatedCart[itemId] = existing.copy(quantity = existing.quantity - 1L)
            }
            state.copy(cart = updatedCart)
        }
    }

    fun clearCart() {
        _formState.update {
            it.copy(
                cart = emptyMap(),
                discountType = DiscountType.NONE,
                customFlatDiscountInput = "",
                cashReceivedInput = ""
            )
        }
    }

    fun updateCustomerPhone(phone: String) {
        val cleaned = phone.filter { it.isDigit() || it == '+' || it == ' ' }.take(16)
        _formState.update { it.copy(customerPhone = cleaned) }
    }

    fun updateCustomerName(name: String) {
        _formState.update { it.copy(customerName = name.take(60)) }
    }

    fun updateOrderType(orderType: String) {
        _formState.update { it.copy(orderType = orderType) }
    }

    fun updatePaymentMethod(method: String) {
        _formState.update { it.copy(paymentMethod = method) }
    }

    fun updateCashReceivedInput(input: String) {
        val digits = input.filter { it.isDigit() }.take(7)
        _formState.update { it.copy(cashReceivedInput = digits) }
    }

    fun selectDiscountType(discountType: DiscountType) {
        _formState.update { it.copy(discountType = discountType) }
    }

    fun updateCustomFlatDiscount(input: String) {
        val digits = input.filter { it.isDigit() }.take(6)
        _formState.update {
            it.copy(
                discountType = DiscountType.FLAT_AMOUNT,
                customFlatDiscountInput = digits
            )
        }
    }

    fun updateCustomTokenOverride(input: String) {
        val digits = input.filter { it.isDigit() }.take(5)
        _formState.update { it.copy(customTokenOverrideInput = digits) }
    }

    fun toggleAutoShareWhatsApp(enabled: Boolean) {
        _formState.update { it.copy(autoShareWhatsAppOnGenerate = enabled) }
    }

    fun selectSettlementPeriod(period: SettlementPeriod) {
        _formState.update { it.copy(settlementPeriod = period) }
    }

    fun updateSettlementWhatsAppPhone(phone: String) {
        val cleaned = phone.filter { it.isDigit() || it == '+' }.take(15)
        _formState.update { it.copy(settlementWhatsAppPhone = cleaned) }
    }

    fun openReceiptPreview(order: OrderRecord) {
        _formState.update { it.copy(activeReceiptOrder = order) }
    }

    fun dismissReceiptPreview() {
        _formState.update { it.copy(activeReceiptOrder = null) }
    }

    fun clearBannerMessage() {
        _formState.update { it.copy(statusBannerMessage = null) }
    }

    fun generateOrderToken(onOrderCreated: (OrderRecord, Boolean) -> Unit = { _, _ -> }) {
        val snapshot = _formState.value
        if (snapshot.cart.isEmpty() || snapshot.isSubmittingOrder) return

        val tokenNum = nextTokenNumber.value
        val now = Date()
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val dateDisplay = SimpleDateFormat("dd MMM yyyy", Locale.US).format(now)
        val timeDisplay = SimpleDateFormat("hh:mm a", Locale.US).format(now)

        val lineItems = snapshot.cartItemsList.map { entry ->
            OrderLineItem(
                itemId = entry.menuItem.id,
                name = entry.menuItem.name,
                category = entry.menuItem.category,
                unitPrice = entry.menuItem.price,
                quantity = entry.quantity,
                lineTotal = entry.lineTotal
            )
        }

        val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val totalQty = lineItems.sumOf { it.quantity }.coerceAtLeast(1L)
        val localRecord = OrderRecord(
            id = orderId,
            userId = currentUserId,
            tokenNumber = tokenNum,
            dateKey = dateKey,
            dateDisplay = dateDisplay,
            timeDisplay = timeDisplay,
            customerPhone = snapshot.customerPhone.trim(),
            customerName = snapshot.customerName.trim(),
            orderType = snapshot.orderType,
            paymentMethod = snapshot.paymentMethod,
            subtotalAmount = snapshot.subtotalAmount,
            discountAmount = snapshot.discountAmount,
            discountLabel = snapshot.discountLabel,
            totalAmount = snapshot.finalPayableAmount,
            totalQuantity = totalQty,
            items = lineItems,
            status = "ACTIVE",
            createdAt = Timestamp.now(),
            updatedAt = Timestamp.now()
        )

        _formState.update { it.copy(isSubmittingOrder = true) }

        viewModelScope.launch {
            // Save locally immediately so token generation works both offline and online
            LocalPosSessionStore.saveLocalOrder(appContext, localRecord)

            // Sync to Firestore if signed in with Firebase Auth
            if (Firebase.auth.currentUser != null) {
                repository.createOrder(
                    tokenNumber = tokenNum,
                    dateKey = dateKey,
                    dateDisplay = dateDisplay,
                    timeDisplay = timeDisplay,
                    customerPhone = snapshot.customerPhone.trim(),
                    customerName = snapshot.customerName.trim(),
                    orderType = snapshot.orderType,
                    paymentMethod = snapshot.paymentMethod,
                    subtotalAmount = snapshot.subtotalAmount,
                    discountAmount = snapshot.discountAmount,
                    discountLabel = snapshot.discountLabel,
                    totalAmount = snapshot.finalPayableAmount,
                    items = lineItems,
                    status = "ACTIVE",
                    orderId = orderId
                )
            }

            val shouldAutoWhatsApp = snapshot.autoShareWhatsAppOnGenerate
            _formState.update {
                it.copy(
                    cart = emptyMap(),
                    discountType = DiscountType.NONE,
                    customFlatDiscountInput = "",
                    customTokenOverrideInput = "",
                    cashReceivedInput = "",
                    isSubmittingOrder = false,
                    activeReceiptOrder = localRecord,
                    statusBannerMessage = "Token #%03d generated!".format(localRecord.tokenNumber)
                )
            }
            onOrderCreated(localRecord, shouldAutoWhatsApp)
        }
    }

    fun updateActiveReceiptPhoneAndOrder(order: OrderRecord, newPhone: String) {
        val cleaned = newPhone.filter { it.isDigit() || it == '+' }.take(15)
        val updatedOrder = order.copy(customerPhone = cleaned)
        _formState.update { it.copy(activeReceiptOrder = updatedOrder, customerPhone = cleaned) }
        LocalPosSessionStore.updateLocalOrderStatus(
            context = appContext,
            orderId = order.id,
            newStatus = order.status,
            customerPhone = cleaned
        )
        if (order.status == "ACTIVE" && Firebase.auth.currentUser != null) {
            viewModelScope.launch {
                repository.updateOrderStatus(
                    orderId = order.id,
                    newStatus = order.status,
                    customerPhone = cleaned
                )
            }
        }
    }

    fun markOrderStatus(order: OrderRecord, newStatus: String) {
        if (order.status != "ACTIVE") return
        viewModelScope.launch {
            LocalPosSessionStore.updateLocalOrderStatus(
                context = appContext,
                orderId = order.id,
                newStatus = newStatus
            )
            if (Firebase.auth.currentUser != null) {
                repository.updateOrderStatus(orderId = order.id, newStatus = newStatus)
            }
            _formState.update { state ->
                val updatedPreview = if (state.activeReceiptOrder?.id == order.id) {
                    state.activeReceiptOrder.copy(status = newStatus)
                } else {
                    state.activeReceiptOrder
                }
                state.copy(
                    activeReceiptOrder = updatedPreview,
                    statusBannerMessage = "Token #%03d marked as $newStatus".format(order.tokenNumber)
                )
            }
        }
    }

    fun saveCustomMenuItem(
        id: String,
        name: String,
        category: String,
        price: Long,
        isVeg: Boolean,
        isAvailable: Boolean
    ) {
        val isExisting = id.isNotBlank()
        val cleanId = id.ifBlank {
            "item_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        }
        val item = MenuItem(
            id = cleanId,
            userId = currentUserId,
            name = name.trim(),
            category = category,
            price = price,
            isVeg = isVeg,
            isAvailable = isAvailable
        )
        viewModelScope.launch {
            LocalPosSessionStore.saveLocalMenuItem(appContext, item)
            if (Firebase.auth.currentUser != null) {
                repository.saveMenuItem(item, isExistingOverride = isExisting)
            }
            _formState.update {
                it.copy(statusBannerMessage = "Saved menu item: ${item.name} (₹${item.price})")
            }
        }
    }

    private fun computeSettlement(
        allOrders: List<OrderRecord>,
        period: SettlementPeriod
    ): SettlementSummary {
        val nowCal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = fmt.format(nowCal.time)

        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterdayStr = fmt.format(yesterdayCal.time)

        val sevenDaysAgoCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6) }
        val sevenDaysAgoStr = fmt.format(sevenDaysAgoCal.time)

        val currentMonthPrefix = todayStr.take(7)

        val periodOrders = allOrders.filter { order ->
            when (period) {
                SettlementPeriod.TODAY -> order.dateKey == todayStr
                SettlementPeriod.YESTERDAY -> order.dateKey == yesterdayStr
                SettlementPeriod.LAST_7_DAYS -> order.dateKey >= sevenDaysAgoStr && order.dateKey <= todayStr
                SettlementPeriod.THIS_MONTH -> order.dateKey.startsWith(currentMonthPrefix)
                SettlementPeriod.ALL_TIME -> true
            }
        }

        val validOrders = periodOrders.filter { it.status != "CANCELLED" }
        val cancelledCount = periodOrders.count { it.status == "CANCELLED" }

        val totalRevenue = validOrders.sumOf { it.totalAmount }
        val totalSubtotal = validOrders.sumOf { it.subtotalAmount }
        val totalDiscount = validOrders.sumOf { it.discountAmount }
        val totalProductsSold = validOrders.sumOf { it.totalQuantity }

        val cashOrders = validOrders.filter { it.paymentMethod == "CASH" }
        val upiOrders = validOrders.filter { it.paymentMethod == "UPI" }
        val otherOrders = validOrders.filter { it.paymentMethod == "OTHER" }

        val cashAmount = cashOrders.sumOf { it.totalAmount }
        val upiAmount = upiOrders.sumOf { it.totalAmount }
        val otherAmount = otherOrders.sumOf { it.totalAmount }

        val productMap = mutableMapOf<String, ProductSalesSummary>()
        validOrders.forEach { order ->
            order.items.forEach { line ->
                val key = "${line.category}::${line.name}"
                val prev = productMap[key]
                if (prev == null) {
                    productMap[key] = ProductSalesSummary(
                        itemId = line.itemId,
                        name = line.name,
                        category = line.category,
                        unitPrice = line.unitPrice,
                        quantitySold = line.quantity,
                        totalRevenue = line.lineTotal
                    )
                } else {
                    productMap[key] = prev.copy(
                        quantitySold = prev.quantitySold + line.quantity,
                        totalRevenue = prev.totalRevenue + line.lineTotal
                    )
                }
            }
        }

        val sortedProducts = productMap.values.sortedWith(
            compareByDescending<ProductSalesSummary> { it.quantitySold }
                .thenByDescending { it.totalRevenue }
        )

        val totalItemRevenue = sortedProducts.sumOf { it.totalRevenue }.coerceAtLeast(1L)

        val categoriesInOrder = (MenuCategories.ALL + sortedProducts.map { it.category }).distinct()
        val categoryBreakdown = categoriesInOrder.mapNotNull { cat ->
            val catProducts = sortedProducts.filter { it.category == cat }
            if (catProducts.isEmpty()) {
                null
            } else {
                val catQty = catProducts.sumOf { it.quantitySold }
                val catRev = catProducts.sumOf { it.totalRevenue }
                CategorySalesSummary(
                    category = cat,
                    totalQuantitySold = catQty,
                    totalRevenue = catRev,
                    revenueSharePercent = (catRev.toFloat() / totalItemRevenue.toFloat()) * 100f,
                    products = catProducts
                )
            }
        }

        val periodLabel = when (period) {
            SettlementPeriod.TODAY -> "Today ($todayStr)"
            SettlementPeriod.YESTERDAY -> "Yesterday ($yesterdayStr)"
            SettlementPeriod.LAST_7_DAYS -> "Last 7 Days ($sevenDaysAgoStr to $todayStr)"
            SettlementPeriod.THIS_MONTH -> "This Month ($currentMonthPrefix)"
            SettlementPeriod.ALL_TIME -> "All Time"
        }

        return SettlementSummary(
            period = period,
            periodLabel = periodLabel,
            totalRevenue = totalRevenue,
            totalSubtotal = totalSubtotal,
            totalDiscountAmount = totalDiscount,
            totalOrdersCount = validOrders.size,
            cancelledOrdersCount = cancelledCount,
            totalProductsSold = totalProductsSold,
            cashAmount = cashAmount,
            cashOrderCount = cashOrders.size,
            upiAmount = upiAmount,
            upiOrderCount = upiOrders.size,
            otherAmount = otherAmount,
            otherOrderCount = otherOrders.size,
            categoryBreakdown = categoryBreakdown,
            productBreakdown = sortedProducts
        )
    }

    private fun currentDateKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    class Factory(
        private val application: Application,
        private val currentUserId: String,
        private val isCloudAuthenticated: Boolean
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PosViewModel(application, currentUserId, isCloudAuthenticated) as T
        }
    }

    private companion object {
        const val TAG = "PosViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
