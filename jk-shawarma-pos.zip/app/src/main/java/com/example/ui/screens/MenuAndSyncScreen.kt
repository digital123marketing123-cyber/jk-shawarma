package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.MenuCategories
import com.example.data.model.MenuItem
import com.example.data.model.RestaurantInfo
import com.example.ui.PosViewModel
import com.example.ui.auth.GoogleSignInButton
import com.example.ui.theme.CrownGold
import com.example.ui.theme.HalalGreen
import com.example.ui.theme.NonVegRed
import com.example.ui.theme.ShawarmaOrange
import com.example.ui.theme.VegGreen

@Composable
fun MenuAndSyncScreen(
    menuCatalog: List<MenuItem>,
    userEmail: String?,
    isCloudConnected: Boolean,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onSignOut: () -> Unit,
    viewModel: PosViewModel
) {
    var editingItem by remember { mutableStateOf<MenuItem?>(null) }
    var isAddingNew by remember { mutableStateOf(false) }
    var syncError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("menu_and_sync_lazy_column"),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Multi-Device Cloud Sync & Approved JANI ADS Account Card
        item(key = "multi_device_sync_card") {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, HalalGreen.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isCloudConnected) Icons.Default.CloudDone else Icons.Default.VerifiedUser,
                                contentDescription = "Account Status",
                                tint = HalalGreen,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "JANI ADS — APPROVED POS LOGIN",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = HalalGreen
                                )
                                Text(
                                    text = "User ID: ${RestaurantInfo.APPROVED_USER_ID} • ${userEmail ?: RestaurantInfo.APPROVED_EMAIL}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CrownGold
                                )
                            }
                        }

                        IconButton(
                            onClick = onToggleTheme,
                            modifier = Modifier.testTag("toggle_theme_button")
                        ) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Dark/Light Theme",
                                tint = CrownGold
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Approved Login User ID: ${RestaurantInfo.APPROVED_USER_ID}",
                                style = MaterialTheme.typography.labelLarge,
                                color = CrownGold
                            )
                            Text(
                                text = "Approved Login Mail ID: ${RestaurantInfo.APPROVED_EMAIL}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Developer: ${RestaurantInfo.DEVELOPER_CREDIT}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (!isCloudConnected) {
                        Text(
                            text = "Want to sync live tokens across multiple devices? Link your approved Google account (${RestaurantInfo.APPROVED_EMAIL}) below:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        GoogleSignInButton(
                            onAuthSuccess = { syncError = null },
                            onAuthError = { syncError = it }
                        )
                        if (!syncError.isNullOrBlank()) {
                            Text(
                                text = syncError!!,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    } else {
                        Text(
                            text = "Multi-device cloud sync is active for ${userEmail ?: RestaurantInfo.APPROVED_EMAIL}. Log in with the same credentials on any other device to access live tokens and settlement reports.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign Out",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Switch Account / Sign Out", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Menu Manager Header + Add Item Button
        item(key = "menu_manager_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RestaurantMenu,
                        contentDescription = "Menu Manager",
                        tint = ShawarmaOrange
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "RESTAURANT MENU & PRICE LIST",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = CrownGold
                        )
                        Text(
                            text = "${menuCatalog.size} items from JK Arabian Shawarma Menu",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = { isAddingNew = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ShawarmaOrange),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("add_custom_menu_item_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Menu Item",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Item", fontWeight = FontWeight.Bold)
                }
            }
        }

        items(items = menuCatalog, key = { it.id }) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        RoundedCornerShape(14.dp)
                    ),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .border(
                                    1.5.dp,
                                    if (item.isVeg) VegGreen else NonVegRed,
                                    RoundedCornerShape(4.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (item.isVeg) VegGreen else NonVegRed)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${item.category} • ₹${item.price}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrownGold
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = item.isAvailable,
                            onCheckedChange = { available ->
                                viewModel.saveCustomMenuItem(
                                    id = item.id,
                                    name = item.name,
                                    category = item.category,
                                    price = item.price,
                                    isVeg = item.isVeg,
                                    isAvailable = available
                                )
                            }
                        )
                        IconButton(onClick = { editingItem = item }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit ${item.name}",
                                tint = CrownGold
                            )
                        }
                    }
                }
            }
        }

        item(key = "menu_sync_footer_credit") {
            Text(
                text = RestaurantInfo.DEVELOPER_CREDIT,
                style = MaterialTheme.typography.labelLarge,
                color = CrownGold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )
        }
    }

    if (isAddingNew || editingItem != null) {
        val initial = editingItem
        MenuItemEditorDialog(
            initialItem = initial,
            onDismiss = {
                isAddingNew = false
                editingItem = null
            },
            onSave = { id, name, category, price, isVeg, isAvailable ->
                viewModel.saveCustomMenuItem(
                    id = id,
                    name = name,
                    category = category,
                    price = price,
                    isVeg = isVeg,
                    isAvailable = isAvailable
                )
                isAddingNew = false
                editingItem = null
            }
        )
    }
}

@Composable
private fun MenuItemEditorDialog(
    initialItem: MenuItem?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Long, Boolean, Boolean) -> Unit
) {
    var name by remember { mutableStateOf(initialItem?.name ?: "") }
    var priceText by remember { mutableStateOf(initialItem?.price?.toString() ?: "150") }
    var category by remember { mutableStateOf(initialItem?.category ?: MenuCategories.CHICKEN_SHAWARMA) }
    var isVeg by remember { mutableStateOf(initialItem?.isVeg ?: false) }
    var isAvailable by remember { mutableStateOf(initialItem?.isAvailable ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialItem == null) "Add Menu Item" else "Edit Menu Item",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(80) },
                    label = { Text("Item Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { ch -> ch.isDigit() }.take(5) },
                    label = { Text("Price (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.labelLarge
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MenuCategories.ALL.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ShawarmaOrange,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isVeg, onCheckedChange = { isVeg = it })
                    Text("Vegetarian Item (Veg)")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val priceVal = (priceText.toLongOrNull() ?: 100L).coerceAtLeast(1L)
                    if (name.isNotBlank()) {
                        onSave(
                            initialItem?.id ?: "",
                            name.trim(),
                            category,
                            priceVal,
                            isVeg,
                            isAvailable
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ShawarmaOrange)
            ) {
                Text("Save Item")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
