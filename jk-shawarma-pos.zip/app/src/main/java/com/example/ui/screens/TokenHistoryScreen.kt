package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.OrderRecord
import com.example.data.model.RestaurantInfo
import com.example.ui.PosViewModel
import com.example.ui.UiState
import com.example.ui.theme.CrownGold
import com.example.ui.theme.HalalGreen
import com.example.ui.theme.ShawarmaOrange
import com.example.ui.theme.WhatsAppGreen
import com.example.util.ReceiptShareHelper

@Composable
fun TokenHistoryScreen(
    ordersState: UiState<List<OrderRecord>>,
    viewModel: PosViewModel
) {
    val context = LocalContext.current
    var paymentFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(
            text = "GENERATED ORDER TOKENS & INVOICES",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            color = CrownGold
        )
        Text(
            text = "Tap any token to view the full invoice or share directly to WhatsApp",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by Token #, Mobile Number, or Item...") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Tokens"
                )
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("token_history_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL", "CASH", "UPI", "OTHER").forEach { filter ->
                FilterChip(
                    selected = paymentFilter == filter,
                    onClick = { paymentFilter = filter },
                    label = {
                        Text(
                            text = if (filter == "ALL") "All Payments" else filter,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ShawarmaOrange,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (ordersState) {
            is UiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = ShawarmaOrange)
                }
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ordersState.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                }
            }

            is UiState.Success -> {
                val filteredOrders = remember(ordersState.data, paymentFilter, searchQuery) {
                    ordersState.data.filter { order ->
                        val matchesPayment = paymentFilter == "ALL" || order.paymentMethod == paymentFilter
                        val q = searchQuery.trim()
                        val matchesQuery = q.isEmpty() ||
                            order.tokenNumber.toString().contains(q) ||
                            ReceiptShareHelper.formatTokenSerial(order.tokenNumber).contains(q, ignoreCase = true) ||
                            order.customerPhone.contains(q) ||
                            order.items.any { it.name.contains(q, ignoreCase = true) }
                        matchesPayment && matchesQuery
                    }
                }

                if (filteredOrders.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = "No Tokens",
                                tint = CrownGold,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "No order tokens found yet",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Generate your first token from the New Token tab.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("token_history_list"),
                        contentPadding = PaddingValues(vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(items = filteredOrders, key = { it.id }) { order ->
                            OrderTokenHistoryCard(
                                order = order,
                                onViewReceipt = { viewModel.openReceiptPreview(order) },
                                onShareWhatsApp = {
                                    if (order.customerPhone.isBlank()) {
                                        // Open receipt preview so cashier can type mobile number & send
                                        viewModel.openReceiptPreview(order)
                                    } else {
                                        val msg = ReceiptShareHelper.buildOrderReceiptText(order)
                                        ReceiptShareHelper.shareToWhatsAppDirect(
                                            context = context,
                                            rawPhoneInput = order.customerPhone,
                                            message = msg
                                        )
                                    }
                                },
                                onMarkCompleted = { viewModel.markOrderStatus(order, "COMPLETED") }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderTokenHistoryCard(
    order: OrderRecord,
    onViewReceipt: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onMarkCompleted: () -> Unit
) {
    val tokenStr = ReceiptShareHelper.formatTokenSerial(order.tokenNumber)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = CrownGold.copy(alpha = 0.35f),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("token_history_card_${order.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(ShawarmaOrange)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "TOKEN $tokenStr",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${order.dateDisplay} • ${order.timeDisplay}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${order.orderType.replace("_", " ")} • ${order.paymentMethod}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrownGold
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "₹${order.totalAmount}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = CrownGold
                    )
                    Surface(
                        color = if (order.status == "CANCELLED") {
                            MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                        } else {
                            HalalGreen.copy(alpha = 0.2f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = order.status,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (order.status == "CANCELLED") MaterialTheme.colorScheme.error else HalalGreen,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

            // Items preview
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                order.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.quantity}x ${item.name}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "₹${item.lineTotal}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (order.customerPhone.isNotBlank()) {
                Text(
                    text = "📱 WhatsApp Mobile: ${order.customerPhone}",
                    style = MaterialTheme.typography.labelSmall,
                    color = WhatsAppGreen
                )
            }

            Text(
                text = RestaurantInfo.DEVELOPER_CREDIT,
                style = MaterialTheme.typography.labelSmall,
                color = CrownGold.copy(alpha = 0.8f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onViewReceipt,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = "View Invoice",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Invoice")
                }

                Button(
                    onClick = onShareWhatsApp,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WhatsAppGreen,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share on WhatsApp",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp", fontWeight = FontWeight.ExtraBold)
                }

                if (order.status == "ACTIVE") {
                    IconButton(
                        onClick = onMarkCompleted,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(ShawarmaOrange.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Mark Completed",
                            tint = ShawarmaOrange
                        )
                    }
                }
            }
        }
    }
}
