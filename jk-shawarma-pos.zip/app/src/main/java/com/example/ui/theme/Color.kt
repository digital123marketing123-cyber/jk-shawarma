package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JK Arabian Shawarma & Grill House Signature Palette
val GrillDarkBg = Color(0xFF120F0D)
val GrillSurface = Color(0xFF1D1815)
val GrillSurfaceVariant = Color(0xFF2B231E)
val GrillCardBorder = Color(0xFF3E322A)

val ShawarmaOrange = Color(0xFFFF6B1A)
val ShawarmaOrangeDark = Color(0xFFD94E05)
val CrownGold = Color(0xFFFFC42E)
val CrownGoldSoft = Color(0xFFFFE082)

val HalalGreen = Color(0xFF1EB980)
val WhatsAppGreen = Color(0xFF25D366)
val VegGreen = Color(0xFF2E7D32)
val NonVegRed = Color(0xFFD32F2F)

val CreamTextPrimary = Color(0xFFFDF8F5)
val WarmTextSecondary = Color(0xFFD7C6B8)
val ErrorCrimson = Color(0xFFFF5252)

// Light Mode Counter Palette
val LightBg = Color(0xFFFFF8F3)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF6EBE2)
val LightTextPrimary = Color(0xFF1F1610)
val LightTextSecondary = Color(0xFF5D4B3E)
