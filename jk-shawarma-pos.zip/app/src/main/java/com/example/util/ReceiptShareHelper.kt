package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.model.OrderRecord
import com.example.data.model.RestaurantInfo
import com.example.ui.SettlementSummary

object ReceiptShareHelper {

    /**
     * Normalizes an entered mobile number for WhatsApp direct wa.me / api.whatsapp.com URL.
     * Defaults 10-digit Indian mobile numbers to +91 (91XXXXXXXXXX).
     */
    fun normalizeWhatsAppPhone(rawInput: String): String {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return when {
            digitsOnly.length == 10 -> "91$digitsOnly"
            digitsOnly.length == 11 && digitsOnly.startsWith("0") -> "91${digitsOnly.drop(1)}"
            digitsOnly.length >= 11 -> digitsOnly
            else -> ""
        }
    }

    fun formatTokenSerial(tokenNumber: Long): String {
        return "#%03d".format(tokenNumber)
    }

    /**
     * Builds the formatted invoice receipt text for an Order Token with:
     * - Top: Restaurant Name, Date, Order Time, Token Serial Number
     * - Middle: Ordered Menu Items with Qty, Unit Price, Line Total
     * - Bottom: Subtotal, Discount, Total Amount, Payment Method, and "Developed by Johnny Ads"
     */
    fun buildOrderReceiptText(order: OrderRecord): String {
        val tokenStr = formatTokenSerial(order.tokenNumber)
        val sb = StringBuilder()
        sb.appendLine("👑 *${RestaurantInfo.NAME}*")
        sb.appendLine("*${RestaurantInfo.SUBTITLE}* (HALAL)")
        sb.appendLine("📍 ${RestaurantInfo.ADDRESS}")
        sb.appendLine("📞 Contact: ${RestaurantInfo.CONTACT}")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("🎫 *TOKEN SERIAL NO: $tokenStr*")
        sb.appendLine("📅 Date: ${order.dateDisplay}")
        sb.appendLine("⏰ Order Time: ${order.timeDisplay}")
        sb.appendLine("🛍️ Order Type: ${order.orderType.replace("_", " ")}")
        if (order.customerName.isNotBlank()) {
            sb.appendLine("👤 Customer: ${order.customerName}")
        }
        if (order.customerPhone.isNotBlank()) {
            sb.appendLine("📱 Mobile: ${order.customerPhone}")
        }
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("*MENU ITEMS (${order.totalQuantity} Qty):*")
        order.items.forEachIndexed { index, item ->
            sb.appendLine(
                "${index + 1}. *${item.name}*\n   ${item.quantity} x ₹${item.unitPrice} = *₹${item.lineTotal}*"
            )
        }
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("Subtotal: ₹${order.subtotalAmount}")
        if (order.discountAmount > 0L) {
            val label = if (order.discountLabel.isNotBlank()) " (${order.discountLabel})" else ""
            sb.appendLine("Discount$label: -₹${order.discountAmount}")
        }
        sb.appendLine("💰 *TOTAL AMOUNT: ₹${order.totalAmount}*")
        sb.appendLine("💳 Payment Method: *${order.paymentMethod}*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("Thank you for ordering at ${RestaurantInfo.NAME}! 🙏")
        sb.append("✨ _${RestaurantInfo.DEVELOPER_CREDIT}_")
        return sb.toString()
    }

    /**
     * Builds the complete Settlement Report text for sharing to WhatsApp.
     */
    fun buildSettlementReportText(summary: SettlementSummary): String {
        val sb = StringBuilder()
        sb.appendLine("📊 *FINAL SETTLEMENT REPORT*")
        sb.appendLine("👑 *${RestaurantInfo.FULL_NAME}*")
        sb.appendLine("📍 ${RestaurantInfo.ADDRESS}")
        sb.appendLine("📅 Period: *${summary.periodLabel}*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("🧾 Total Tokens / Orders: *${summary.totalOrdersCount}*")
        sb.appendLine("🥙 Total Products Sold: *${summary.totalProductsSold} Qty*")
        if (summary.totalDiscountAmount > 0L) {
            sb.appendLine("🏷️ Total Discounts Given: *₹${summary.totalDiscountAmount}*")
        }
        sb.appendLine("💰 *NET TOTAL SALES: ₹${summary.totalRevenue}*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("💳 *PAYMENT BREAKDOWN:*")
        sb.appendLine("💵 Cash Sales: *₹${summary.cashAmount}* (${summary.cashOrderCount} orders)")
        sb.appendLine("📱 Online / UPI Sales: *₹${summary.upiAmount}* (${summary.upiOrderCount} orders)")
        if (summary.otherAmount > 0L || summary.otherOrderCount > 0) {
            sb.appendLine("💳 Other Payment: *₹${summary.otherAmount}* (${summary.otherOrderCount} orders)")
        }
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("📂 *CATEGORY-WISE & PRODUCT SALES DETAIL:*")
        if (summary.categoryBreakdown.isEmpty()) {
            sb.appendLine("No completed sales in this period.")
        } else {
            summary.categoryBreakdown.forEach { cat ->
                sb.appendLine("\n🔸 *${cat.category}* — ${cat.totalQuantitySold} Qty | *₹${cat.totalRevenue}*")
                cat.products.forEach { prod ->
                    sb.appendLine("   • ${prod.name}: *${prod.quantitySold} Qty* (₹${prod.totalRevenue})")
                }
            }
        }
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.append("✨ _${RestaurantInfo.DEVELOPER_CREDIT}_")
        return sb.toString()
    }

    /**
     * Directly launches WhatsApp chat with the entered mobile number and pre-filled message.
     * Falls back gracefully to standard Share sheet + Clipboard if WhatsApp is not installed.
     */
    fun shareToWhatsAppDirect(
        context: Context,
        rawPhoneInput: String,
        message: String
    ) {
        val normalizedPhone = normalizeWhatsAppPhone(rawPhoneInput)
        val encodedText = Uri.encode(message)

        // Build direct wa.me / api.whatsapp.com URI
        val whatsappUri = if (normalizedPhone.isNotEmpty()) {
            Uri.parse("https://api.whatsapp.com/send?phone=$normalizedPhone&text=$encodedText")
        } else {
            Uri.parse("https://api.whatsapp.com/send?text=$encodedText")
        }

        // 1. Try explicit WhatsApp or WhatsApp Business intent first
        val packagesToTry = listOf("com.whatsapp", "com.whatsapp.w4b")
        for (pkg in packagesToTry) {
            try {
                val directIntent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (directIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(directIntent)
                    return
                }
            } catch (_: Exception) {
                // Continue to fallback
            }
        }

        // 2. Try opening https://wa.me/<phone>?text=... via system browser / handler
        try {
            val waMeUri = if (normalizedPhone.isNotEmpty()) {
                Uri.parse("https://wa.me/$normalizedPhone?text=$encodedText")
            } else {
                Uri.parse("https://wa.me/?text=$encodedText")
            }
            val browserIntent = Intent(Intent.ACTION_VIEW, waMeUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            return
        } catch (_: Exception) {
            // Continue to system share chooser fallback
        }

        // 3. Fallback: Copy receipt to clipboard and open Android Share Sheet
        copyToClipboard(context, "JK Shawarma Receipt", message)
        shareViaSystemSheet(context, message)
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
            Toast.makeText(context, "Receipt copied to clipboard!", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            // Ignore in headless test environment
        }
    }

    fun shareViaSystemSheet(context: Context, message: String) {
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(sendIntent, "Share JK Shawarma Receipt").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (_: Exception) {
            Toast.makeText(context, "Receipt ready to share", Toast.LENGTH_SHORT).show()
        }
    }
}
