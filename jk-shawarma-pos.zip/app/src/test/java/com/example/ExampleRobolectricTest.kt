package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.LocalPosSessionStore
import com.example.data.model.DefaultMenuCatalog
import com.example.data.model.MenuCategories
import com.example.data.model.OrderLineItem
import com.example.data.model.OrderRecord
import com.example.util.ReceiptShareHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name and verify 25 PDF menu items and JANI ADS credentials`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JK Shawarma POS", appName)
        assertEquals("Developed by JANI ADS", context.getString(R.string.developer_credit))
        assertEquals(25, DefaultMenuCatalog.ITEMS.size)

        assertTrue(LocalPosSessionStore.validatePosCredentials("janiads", "Janiads001"))
        assertTrue(LocalPosSessionStore.validatePosCredentials("janiads", "janiads001"))
        assertTrue(LocalPosSessionStore.validatePosCredentials("janidigitalads@gmail.com", "Janiads001"))
        assertTrue(LocalPosSessionStore.validatePosCredentials("janidigitalads@gmail.com", "janiads001"))
        assertFalse(LocalPosSessionStore.validatePosCredentials("janiads", "wrongpass"))
        assertTrue(LocalPosSessionStore.isApprovedGoogleEmail("janidigitalads@gmail.com"))
    }

    @Test
    fun `buildOrderReceiptText includes restaurant header token serial total and JANI ADS credit`() {
        val order = OrderRecord(
            id = "ord_test_5",
            userId = "janiads",
            tokenNumber = 5L,
            dateKey = "2026-09-30",
            dateDisplay = "30 Sep 2026",
            timeDisplay = "03:00 PM",
            customerPhone = "8688553379",
            customerName = "Raju",
            orderType = "TAKEAWAY",
            paymentMethod = "UPI",
            subtotalAmount = 525L,
            discountAmount = 25L,
            discountLabel = "Flat ₹25 OFF",
            totalAmount = 500L,
            totalQuantity = 2L,
            items = listOf(
                OrderLineItem(
                    itemId = "full_grill_chicken",
                    name = "Full Grill Chicken",
                    category = MenuCategories.GRILLED_CHICKEN,
                    unitPrice = 500L,
                    quantity = 1L,
                    lineTotal = 500L
                ),
                OrderLineItem(
                    itemId = "rumali_roti",
                    name = "Rumali Roti",
                    category = MenuCategories.BREADS_AND_EXTRAS,
                    unitPrice = 25L,
                    quantity = 1L,
                    lineTotal = 25L
                )
            ),
            status = "ACTIVE"
        )

        val receipt = ReceiptShareHelper.buildOrderReceiptText(order)
        assertTrue(receipt.contains("JK ARABIAN SHAWARMA"))
        assertTrue(receipt.contains("#005"))
        assertTrue(receipt.contains("Full Grill Chicken"))
        assertTrue(receipt.contains("₹500"))
        assertTrue(receipt.contains("Developed by JANI ADS"))
        assertEquals("918688553379", ReceiptShareHelper.normalizeWhatsAppPhone("86885 53379"))
    }
}
