package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.MenuCategories
import com.example.data.model.OrderLineItem
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class PosRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun createOrder_validPayload_createsDocumentAndEmitsRealtime() = runBlocking {
    val uid = signInTestUser(ALICE_EMAIL)
    val repository = PosRepository(firestore, auth)
    val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(16)}"

    val items = listOf(
      OrderLineItem(
        itemId = "special_chicken_shawarma",
        name = "Special Chicken Shawarma",
        category = MenuCategories.JK_SPECIAL_SHAWARMA,
        unitPrice = 150L,
        quantity = 2L,
        lineTotal = 300L
      )
    )

    val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.createOrder(
        tokenNumber = 1L,
        dateKey = "2026-09-30",
        dateDisplay = "30 Sep 2026",
        timeDisplay = "02:30 PM",
        customerPhone = "8688553379",
        customerName = "Customer",
        orderType = "TAKEAWAY",
        paymentMethod = "UPI",
        subtotalAmount = 300L,
        discountAmount = 20L,
        discountLabel = "Promo ₹20",
        totalAmount = 280L,
        items = items,
        status = "ACTIVE",
        orderId = orderId
      )
    }

    assertTrue("Expected order creation to succeed", createResult.isSuccess)
    val created = createResult.getOrThrow()
    assertEquals(orderId, created.id)

    val observedOrders = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeOrders(uid).first { list -> list.any { it.id == orderId } }
    }
    assertTrue(observedOrders.any { it.id == orderId && it.totalAmount == 280L })
  }

  @Test
  fun getOrderById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = PosRepository(firestore, auth)
    val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(16)}"

    val items = listOf(
      OrderLineItem(
        itemId = "chicken_shawarma",
        name = "Chicken Shawarma",
        category = MenuCategories.CHICKEN_SHAWARMA,
        unitPrice = 110L,
        quantity = 1L,
        lineTotal = 110L
      )
    )

    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.createOrder(
        tokenNumber = 2L,
        dateKey = "2026-09-30",
        dateDisplay = "30 Sep 2026",
        timeDisplay = "02:35 PM",
        customerPhone = "",
        customerName = "",
        orderType = "DINE_IN",
        paymentMethod = "CASH",
        subtotalAmount = 110L,
        discountAmount = 0L,
        discountLabel = "",
        totalAmount = 110L,
        items = items,
        status = "ACTIVE",
        orderId = orderId
      ).getOrThrow()
    }

    signInTestUser(BOB_EMAIL)
    val bobRepo = PosRepository(firestore, auth)
    val bobResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.getOrderById(aliceUid, orderId)
    }

    assertTrue("Expected cross-user read to fail", bobResult.isFailure)
    val ex = bobResult.exceptionOrNull() as? FirebaseFirestoreException
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ex?.code)
  }

  @Test
  fun observeOrders_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repository = PosRepository(firestore, auth)

    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repository.observeOrders("unauth_uid_123").first()
      }
      fail("Expected FirebaseFirestoreException for unauthenticated user")
    } catch (e: Throwable) {
      val firestoreEx = generateSequence(e) { it.cause }
        .filterIsInstance<FirebaseFirestoreException>()
        .firstOrNull()
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }
  }

  private companion object {
    const val ALICE_EMAIL = "alice@jkshawarma.com"
    const val BOB_EMAIL = "bob@jkshawarma.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
